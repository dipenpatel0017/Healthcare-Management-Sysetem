// // Simple PDF generator using browser APIs
export function generatePDF(html: string, filename: string) {
  const blob = new Blob([html], { type: "text/html" })
  const url = URL.createObjectURL(blob)
  const win = window.open(url, "_blank")
  if (!win) {
    alert("Please enable pop-ups to view the PDF")
    return
  }
  win.document.title = filename
  win.onload = () => {
    const btn = win.document.createElement("button")
    btn.innerText = "Print / Save"
    Object.assign(btn.style, {
      position: "fixed",
      top: "10px",
      right: "10px",
      padding: "8px 16px",
      backgroundColor: "#2e7d32",
      color: "#fff",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
      zIndex: "9999",
    })
    btn.onclick = () => {
      btn.style.display = "none"
      win.print()
      btn.style.display = "block"
    }
    win.document.body.appendChild(btn)
  }
}

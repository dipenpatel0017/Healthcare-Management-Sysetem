// "use client"

// import { useState } from "react"
// import { useRouter } from "next/navigation"
// import type React from "react"
// import Link from "next/link"
// import Image from "next/image"

// import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
// import { Button } from "@/components/ui/button"
// import {
//   DropdownMenu,
//   DropdownMenuContent,
//   DropdownMenuItem,
//   DropdownMenuLabel,
//   DropdownMenuSeparator,
//   DropdownMenuTrigger,
// } from "@/components/ui/dropdown-menu"
// import { createClient } from "@/lib/supabase/client"
// import { LogOut, Settings, User, Menu, Bell } from "lucide-react"
// import { clearUserSession } from "@/lib/browser-storage"
// import Sidebar from "./sidebar"

// interface DashboardLayoutProps {
//   children: React.ReactNode
//   userRole: string
//   userName: string
//   userAvatar?: string
// }

// export default function DashboardLayout({
//   children,
//   userRole,
//   userName,
//   userAvatar,
// }: DashboardLayoutProps) {
//   const router = useRouter()
//   const supabase = createClient()
//   const [isSigningOut, setIsSigningOut] = useState(false)
//   const [isSidebarOpen, setIsSidebarOpen] = useState(true)
//   const [isMuted, setIsMuted] = useState(false)
//   const [notifications, setNotifications] = useState([
//     "📅 New appointment scheduled",
//     "📂 Report uploaded by Dr. Smith",
//     "⚠️ Maintenance at 10PM",
//   ])

//   const handleSignOut = async () => {
//     try {
//       setIsSigningOut(true)
//       await supabase.auth.signOut()
//       clearUserSession()
//       router.push("/")
//     } catch (error) {
//       console.error("Error signing out:", error)
//     } finally {
//       setIsSigningOut(false)
//     }
//   }

//   const getInitials = (name: string) =>
//     name
//       .split(" ")
//       .map((n) => n[0])
//       .join("")
//       .toUpperCase()

//   const toggleSidebar = () => {
//     setIsSidebarOpen(!isSidebarOpen)
//   }

//   const profilePath =
//     userRole === "admin"
//       ? "/admin/profile"
//       : userRole === "doctor"
//       ? "/doctor/profile"
//       : "/patient/profile"

//   const settingsPath =
//     userRole === "admin"
//       ? "/admin/settings"
//       : userRole === "doctor"
//       ? "/doctor/settings"
//       : "/patient/settings"

//   return (
//     <div className="flex min-h-screen bg-white flex-col">
//       <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-white px-4 md:px-6">
//         <Button
//           variant="ghost"
//           size="icon"
//           className="md:hidden"
//           onClick={toggleSidebar}
//         >
//           <Menu className="h-5 w-5" />
//         </Button>

//         {/* Logo + Title */}
//         <Link
//           href="/dashboard"
//           className="flex items-center gap-2 font-semibold"
//         >
//           <Image
//             src="https://i.pinimg.com/originals/3f/d7/d6/3fd7d62d51f0ce46112f4d7eb562fa93.png"
//             alt="HealthCare Logo"
//             width={40}
//             height={40}
//             priority
//           />
//           <span className="text-xl font-bold">HealthCare</span>
//         </Link>

//         <nav className="ml-auto flex items-center gap-4 md:gap-6">
//           {/* Notifications */}
//           <DropdownMenu>
//             <DropdownMenuTrigger asChild>
//               <Button variant="ghost" size="icon" className="relative">
//                 <Bell className="h-5 w-5" />
//                 {notifications.length > 0 && !isMuted && (
//                   <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500" />
//                 )}
//               </Button>
//             </DropdownMenuTrigger>
//             <DropdownMenuContent align="end" className="w-72">
//               <DropdownMenuLabel>Notifications</DropdownMenuLabel>
//               <DropdownMenuSeparator />
//               {!isMuted ? (
//                 notifications.map((note, i) => (
//                   <DropdownMenuItem key={i}>{note}</DropdownMenuItem>
//                 ))
//               ) : (
//                 <DropdownMenuItem className="italic text-muted-foreground">
//                   Notifications muted
//                 </DropdownMenuItem>
//               )}
//               <DropdownMenuSeparator />
//               <DropdownMenuItem onClick={() => setIsMuted(!isMuted)}>
//                 {isMuted ? "🔈 Unmute Notifications" : "🔇 Mute Notifications"}
//               </DropdownMenuItem>
//             </DropdownMenuContent>
//           </DropdownMenu>

//           {/* User Menu */}
//           <DropdownMenu>
//             <DropdownMenuTrigger asChild>
//               <Button variant="ghost" className="relative h-8 w-8 rounded-full">
//                 <Avatar className="h-8 w-8">
//                   <AvatarImage src={userAvatar || "/placeholder.svg"} alt={userName} />
//                   <AvatarFallback>{getInitials(userName)}</AvatarFallback>
//                 </Avatar>
//               </Button>
//             </DropdownMenuTrigger>
//             <DropdownMenuContent
//               className="w-56 bg-white"
//               align="end"
//               forceMount
//             >
//               <DropdownMenuLabel className="font-normal">
//                 <div className="flex flex-col space-y-1">
//                   <p className="text-sm font-medium leading-none">{userName}</p>
//                   <p className="text-xs leading-none text-muted-foreground">
//                     {userRole.charAt(0).toUpperCase() + userRole.slice(1)}
//                   </p>
//                 </div>
//               </DropdownMenuLabel>
//               <DropdownMenuSeparator />
//               <DropdownMenuItem asChild>
//                 <Link href={profilePath}>
//                   <User className="mr-2 h-4 w-4" />
//                   Profile
//                 </Link>
//               </DropdownMenuItem>
//               <DropdownMenuItem asChild>
//                 <Link href={settingsPath}>
//                   <Settings className="mr-2 h-4 w-4" />
//                   Settings
//                 </Link>
//               </DropdownMenuItem>
//               <DropdownMenuSeparator />
//               <DropdownMenuItem
//                 onClick={handleSignOut}
//                 disabled={isSigningOut}
//                 className="cursor-pointer"
//               >
//                 <LogOut className="mr-2 h-4 w-4" />
//                 {isSigningOut ? "Signing out..." : "Sign out"}
//               </DropdownMenuItem>
//             </DropdownMenuContent>
//           </DropdownMenu>
//         </nav>
//       </header>

//       <div className="flex flex-1">
//         <Sidebar
//           userRole={userRole as "doctor" | "patient" | "admin"}
//           userName={userName}
//           userAvatar={userAvatar}
//         />
//         <main className="flex-1">{children}</main>
//       </div>
//     </div>
//   )
// }

"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import type React from "react"
import Link from "next/link"
import Image from "next/image"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { createClient } from "@/lib/supabase/client"
import { LogOut, Settings, User, Menu, Bell } from "lucide-react"
import { clearUserSession } from "@/lib/browser-storage"
import Sidebar from "./sidebar"

interface DashboardLayoutProps {
  children: React.ReactNode
  userRole: string
  userName: string
  userAvatar?: string
}

export default function DashboardLayout({
  children,
  userRole,
  userName,
  userAvatar,
}: DashboardLayoutProps) {
  const router = useRouter()
  const supabase = createClient()
  const [isSigningOut, setIsSigningOut] = useState(false)
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isMuted, setIsMuted] = useState(false)
  const [notifications, setNotifications] = useState([
    "📅 New appointment scheduled",
    "📂 Report uploaded by Dr. Smith",
    "⚠️ Maintenance at 10PM",
  ])

  const handleSignOut = async () => {
    try {
      setIsSigningOut(true)
      await supabase.auth.signOut()
      clearUserSession()
      router.push("/")
    } catch (error) {
      console.error("Error signing out:", error)
    } finally {
      setIsSigningOut(false)
    }
  }

  const getInitials = (name: string) =>
    name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen)
  }

  const profilePath =
    userRole === "admin"
      ? "/admin/profile"
      : userRole === "doctor"
      ? "/doctor/profile"
      : "/patient/profile"

  const settingsPath =
    userRole === "admin"
      ? "/admin/settings"
      : userRole === "doctor"
      ? "/doctor/settings"
      : "/patient/settings"

  return (
    <div className="flex min-h-screen bg-white flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-gradient-to-r from-blue-100 to-green-100 px-4 md:px-6 shadow-sm">
        <Button
          variant="ghost"
          size="icon"
          className="md:hidden text-teal-700 hover:bg-green-100"
          onClick={toggleSidebar}
        >
          <Menu className="h-5 w-5" />
        </Button>

        {/* Logo + Title */}
        <Link
          href="/dashboard"
          className="flex items-center gap-2 font-semibold"
        >
          <Image
            src="https://media-hosting.imagekit.io/0490645fd3ab43bd/3fd7d62d51f0ce46112f4d7eb562fa93-removebg-preview.png?Expires=1841750877&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=iqgCx1IBub0VdxHfANwV3YzEnrMe5Zmji1eAdsCNI5WTFBTfCe6zg5pdtpDr7vQuThxC8uImLEVG~Ga31JxrAVrOwjTBkE9thwN0SBS12xUbRc~QamBDfrV-2XgDVG7JytYoNzdmEnuCPlJ~IlTwaGtoqquvwBuj-Ig3zQiG~0Ck3nagOnWQryKlwrwITBLY04G3zVk5EpOPGg4Pnusp47lutmIYSse7d-3nRC9zlJQueTvkeYssAkAm9jOzA0skaWlUSnHapK~A-8ImA8gl4GwdhEiNyEb24juVCYjRZJQodDQmTRc0SeE8QLtETC86~LdXWatH1QgcXuAPDrhGdA__"
            alt="HealthCare Logo"
            width={40}
            height={40}
            priority
          />
          <span className="text-xl font-bold text-teal-800">HealthCare</span>
        </Link>

        <nav className="ml-auto flex items-center gap-4 md:gap-6">
          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative text-teal-700 hover:bg-green-100">
                <Bell className="h-5 w-5" />
                {notifications.length > 0 && !isMuted && (
                  <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-72 bg-white">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {!isMuted ? (
                notifications.map((note, i) => (
                  <DropdownMenuItem key={i}>{note}</DropdownMenuItem>
                ))
              ) : (
                <DropdownMenuItem className="italic text-muted-foreground">
                  Notifications muted
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setIsMuted(!isMuted)}>
                {isMuted ? "🔈 Unmute Notifications" : "🔇 Mute Notifications"}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={userAvatar || "/placeholder.svg"} alt={userName} />
                  <AvatarFallback>{getInitials(userName)}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              className="w-56 bg-white"
              align="end"
              forceMount
            >
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{userName}</p>
                  <p className="text-xs leading-none text-muted-foreground">
                    {userRole.charAt(0).toUpperCase() + userRole.slice(1)}
                  </p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href={profilePath}>
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href={settingsPath}>
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={handleSignOut}
                disabled={isSigningOut}
                className="cursor-pointer"
              >
                <LogOut className="mr-2 h-4 w-4" />
                {isSigningOut ? "Signing out..." : "Sign out"}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>
      </header>

      <div className="flex flex-1">
        <Sidebar
          userRole={userRole as "doctor" | "patient" | "admin"}
          userName={userName}
          userAvatar={userAvatar}
        />
        <main className="flex-1">{children}</main>
      </div>
    </div>
  )
}

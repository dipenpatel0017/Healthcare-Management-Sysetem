"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  LayoutDashboard,
  Calendar,
  Users,
  User,
  Settings,
  FileText,
  CreditCard,
  Pill,
  Clipboard,
  LogOut,
  ShieldCheck,
  ChevronLeft,
  FilePlus,
} from "lucide-react"
import { toast } from "@/components/ui/use-toast"
import { clearUserSession } from "@/lib/browser-storage"

interface SidebarProps {
  userRole: "doctor" | "patient" | "admin"
  userName: string
  userAvatar?: string | null
  children?: React.ReactNode
}

export default function SidebarLayout({ userRole, userName, userAvatar, children }: SidebarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const [collapsed, setCollapsed] = useState(false)
  const [initials, setInitials] = useState("")
  const [isSigningOut, setIsSigningOut] = useState(false)

  useEffect(() => {
    if (userName) {
      const nameParts = userName.split(" ")
      const initials = nameParts.map((part) => part[0]).join("")
      setInitials(initials)
    }
  }, [userName])

  const handleSignOut = async () => {
    try {
      setIsSigningOut(true)
      clearUserSession()

      toast({
        title: "Signed out successfully",
        description: "You have been signed out of your account.",
      })

      router.push("/")
    } catch (error: any) {
      console.error("Error signing out:", error.message)
      toast({
        title: "Error signing out",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsSigningOut(false)
    }
  }

  const navItems =
    userRole === "doctor"
      ? [
          { href: "/dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-5 w-5" /> },
          { href: "/appointments", label: "Appointments", icon: <FileText className="h-5 w-5" /> },
          { href: "/appointment-calendar", label: "Appointment Calendar", icon: <Calendar className="h-5 w-5" /> },
          { href: "/patients", label: "My Patients", icon: <Users className="h-5 w-5" /> },
          { href: "/prescriptions", label: "Prescriptions", icon: <Pill className="h-5 w-5" /> },
          { href: "/reports/create", label: "Create Reports", icon: <FilePlus className="h-5 w-5" /> },
          { href: "/doctor/profile", label: "Profile", icon: <User className="h-5 w-5" /> },
          { href: "/doctor/settings", label: "Settings", icon: <Settings className="h-5 w-5" /> },
        ]
      : userRole === "patient"
      ? [
          { href: "/dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-5 w-5" /> },
          { href: "/book-appointment", label: "Book Appointment", icon: <FileText className="h-5 w-5" /> },
          { href: "/appointment-calendar", label: "Appointment Calendar", icon: <Calendar className="h-5 w-5" /> },
          { href: "/reports", label: "View Reports", icon: <FileText className="h-5 w-5" /> },
          { href: "/prescriptions", label: "My Prescriptions", icon: <Pill className="h-5 w-5" /> },
          { href: "/medical-records", label: "My Records", icon: <Clipboard className="h-5 w-5" /> },
          { href: "/invoices", label: "Invoices", icon: <CreditCard className="h-5 w-5" /> },
          { href: "/patient/profile", label: "Profile", icon: <User className="h-5 w-5" /> },
          { href: "/patient/settings", label: "Settings", icon: <Settings className="h-5 w-5" /> },
        ]
      : [
          { href: "/admin/dashboard", label: "Dashboard", icon: <LayoutDashboard className="h-5 w-5" /> },
          { href: "/admin/control-center", label: "Control Center", icon: <ShieldCheck className="h-5 w-5" /> },
          { href: "/admin/profile", label: "Profile", icon: <User className="h-5 w-5" /> },
          { href: "/admin/settings", label: "Settings", icon: <Settings className="h-5 w-5" /> },
        ]

  const getNavGroups = () => {
    if (userRole === "doctor") {
      return {
        main: navItems.slice(0, 3),
        patients: navItems.slice(3, 7),
        account: navItems.slice(7),
      }
    } else if (userRole === "patient") {
      return {
        appointments: navItems.slice(0, 3),
        records: navItems.slice(3, 7),
        account: navItems.slice(7),
      }
    }
    return { admin: navItems }
  }

  const navGroups = getNavGroups()

  return (
    <div className="flex min-h-screen">
     {/* Sidebar */}
<div
  className={cn(
    "h-screen bg-gradient-to-b from-sky-50 to-pink-50 border-r transition-all duration-300 sticky top-0 shrink-0", 
    collapsed ? "w-20" : "w-72"
  )}
>
  {/* Header */}
  <div className="flex items-center justify-between p-5 border-b bg-gradient-to-r from-blue-100 to-green-100">
    <div className={cn("flex items-center", collapsed && "justify-center w-full")}>
      <Avatar className="h-10 w-10 ring-2 ring-pink-400/40 ring-offset-2">
        <AvatarImage src={userAvatar || undefined} alt={userName} />
        <AvatarFallback className="bg-purple-600 text-white font-medium">
          {initials}
        </AvatarFallback>
      </Avatar>
      {!collapsed && (
        <div className="ml-3 overflow-hidden">
          <p className="font-semibold text-sm truncate text-sky-700">{userName}</p>
          <p className="text-xs text-muted-foreground capitalize">{userRole}</p>
        </div>
      )}
    </div>
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setCollapsed(!collapsed)}
      className={cn("hover:bg-blue-100", collapsed ? "ml-auto" : "")}
      aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
    >
      <ChevronLeft className={cn("h-5 w-5 transition-transform", collapsed && "rotate-180")} />
    </Button>
  </div>


    {/* Navigation */}
        <div className="flex flex-col h-[calc(100vh-77px)] justify-between">
          <nav className="flex-1 overflow-y-auto py-6 px-3 space-y-6">
            {Object.entries(navGroups).map(([groupName, items]) => (
              <div key={groupName} className="space-y-1">
                {!collapsed && (
                  <h3 className="px-4 text-xs font-semibold text-green-700/70 uppercase tracking-wider mb-2">
                    {groupName}
                  </h3>
                )}
                <ul className="space-y-1">
                  {items.map((item) => {
                    const isActive = pathname === item.href
                    return (
                      <li key={item.href}>
                        <Link href={item.href} passHref>
                          <Button
                            variant={isActive ? "secondary" : "ghost"}
                            className={cn(
                              "w-full justify-start group transition-all duration-200",
                              collapsed ? "justify-center p-2" : "px-4 py-2",
                              isActive
                                ? "bg-blue-100 text-blue-700 hover:bg-blue-200"
                                : "hover:bg-green-50 text-gray-700"
                            )}
                          >
                            <div
                              className={cn(
                                "flex items-center justify-center",
                                isActive ? "text-blue-600" : "text-gray-500 group-hover:text-green-600",
                                collapsed ? "w-full" : "mr-3"
                              )}
                            >
                              {item.icon}
                            </div>
                            {!collapsed && (
                              <span className={cn("truncate", isActive && "font-semibold")}>
                                {item.label}
                              </span>
                            )}
                          </Button>
                        </Link>
                      </li>
                    )
                  })}
                </ul>
              </div>
            ))}
          </nav>

          {/* Sign Out */}
          <div className="p-4 border-t bg-blue-50">
            <Button
              variant="ghost"
              className={cn(
                "w-full justify-start group transition-all duration-200",
                collapsed ? "justify-center p-2" : "px-4 py-2",
                "text-gray-700 hover:bg-red-50 hover:text-red-600"
              )}
              onClick={handleSignOut}
              disabled={isSigningOut}
            >
              <div
                className={cn(
                  "flex items-center justify-center text-gray-500 group-hover:text-red-600",
                  collapsed ? "w-full" : "mr-3"
                )}
              >
                <LogOut className="h-5 w-5" />
              </div>
              {!collapsed && (
                <span className="truncate">
                  {isSigningOut ? "Signing Out..." : "Sign Out"}
                </span>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Main content */}
  <div className="flex-1">{children}</div> {/* Ensure this is correctly placed */}
</div>
  )
}

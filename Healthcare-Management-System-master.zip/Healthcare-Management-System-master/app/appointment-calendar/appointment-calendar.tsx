// "use client"

// import { useState } from "react"
// import { Button } from "@/components/ui/button"
// import { Card, CardContent } from "@/components/ui/card"
// import { ChevronLeft, ChevronRight } from "lucide-react"

// interface Appointment {
//   id: string
//   title: string
//   appointmentDate: string
//   appointmentTime: string
//   status: "upcoming" | "completed" | "cancelled"
//   patients?: { full_name: string }
//   doctors?: { profiles: { full_name: string } }
//   diseases?: string[]  // Adding diseases info to each appointment
// }

// interface AppointmentCalendarProps {
//   appointments: Appointment[]
//   userRole: "doctor" | "patient"
// }

// export default function AppointmentCalendar({ appointments, userRole }: AppointmentCalendarProps) {
//   const [currentDate, setCurrentDate] = useState(new Date())
//   const [hoveredDay, setHoveredDay] = useState<Date | null>(null) // To store the hovered day
//   const [tooltipPosition, setTooltipPosition] = useState<{ top: number, left: number }>({ top: 0, left: 0 }) // Tooltip position

//   // Helper functions for date manipulation without date-fns
//   const getDaysInMonth = (year: number, month: number) => {
//     return new Date(year, month + 1, 0).getDate()
//   }

//   const getFirstDayOfMonth = (year: number, month: number) => {
//     return new Date(year, month, 1).getDay()
//   }

//   const formatMonthYear = (date: Date) => {
//     return date.toLocaleDateString("en-US", { month: "long", year: "numeric" })
//   }

//   const isSameDay = (date1: Date, date2: Date) => {
//     return (
//       date1.getFullYear() === date2.getFullYear() &&
//       date1.getMonth() === date2.getMonth() &&
//       date1.getDate() === date2.getDate()
//     )
//   }

//   const isToday = (date: Date) => {
//     const today = new Date()
//     return isSameDay(date, today)
//   }

//   const parseDate = (dateString: string) => {
//     try {
//       return new Date(dateString)
//     } catch (error) {
//       console.error("Error parsing date:", error)
//       return new Date()
//     }
//   }

//   const prevMonth = () => {
//     const newDate = new Date(currentDate)
//     newDate.setMonth(newDate.getMonth() - 1)
//     setCurrentDate(newDate)
//   }

//   const nextMonth = () => {
//     const newDate = new Date(currentDate)
//     newDate.setMonth(newDate.getMonth() + 1)
//     setCurrentDate(newDate)
//   }

//   const goToToday = () => {
//     setCurrentDate(new Date())
//   }

//   const year = currentDate.getFullYear()
//   const month = currentDate.getMonth()
//   const daysInMonth = getDaysInMonth(year, month)
//   const firstDayOfMonth = getFirstDayOfMonth(year, month)

//   // Create calendar days array
//   const days = []
//   // Add empty cells for days before the first day of the month
//   for (let i = 0; i < firstDayOfMonth; i++) {
//     days.push(null)
//   }
//   // Add days of the month
//   for (let i = 1; i <= daysInMonth; i++) {
//     days.push(new Date(year, month, i))
//   }

//   const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

//   const getAppointmentsForDay = (day: Date | null) => {
//     if (!day) return []

//     return appointments.filter((appointment) => {
//       if (!appointment.appointmentDate) {
//         return false
//       }
//       try {
//         const appointmentDate = parseDate(appointment.appointmentDate)
//         return isSameDay(appointmentDate, day)
//       } catch (error) {
//         console.error("Error comparing dates:", error)
//         return false
//       }
//     })
//   }

//   return (
//     <Card className="relative rounded-xl"> {/* Added relative class to Card for absolute positioning */}
//       <CardContent className="p-6">
//         <div className="flex justify-between items-center mb-6">
//           <h2 className="text-2xl font-bold">{formatMonthYear(currentDate)}</h2>
//           <div className="flex space-x-2">
//             <Button className="rounded-xl" variant="outline" size="sm" onClick={goToToday}>
//               Today
//             </Button>
//             <div className="flex">
//               <Button className="rounded-xl" variant="outline" size="icon" onClick={prevMonth}>
//                 <ChevronLeft className="h-4 w-4" />
//               </Button>
//               <Button className="rounded-xl" variant="outline" size="icon" onClick={nextMonth}>
//                 <ChevronRight className="h-4 w-4" />
//               </Button>
//             </div>
//           </div>
//         </div>

//         <div className="grid grid-cols-7 gap-px bg-gray-200">
//           {daysOfWeek.map((day) => (
//             <div key={day} className="bg-white p-2 text-center font-medium">
//               {day}
//             </div>
//           ))}

//           {days.map((day, index) => {
//             if (!day) {
//               return <div key={`empty-${index}`} className="bg-white p-2 min-h-[100px]"></div>
//             }

//             const dayAppointments = getAppointmentsForDay(day)
//             const isCurrentDay = isToday(day)

//             return (
//               <div
//                 key={day.toString()}
//                 className={`bg-white p-2 min-h-[100px] ${isCurrentDay ? "bg-gray-50" : ""} cursor-pointer`} // Added cursor-pointer class
//                 onClick={() => console.log(`Clicked on: ${day.toDateString()}`)} // Optional: handle click event
//                 onMouseEnter={(e) => {
//                   // Update tooltip position based on the cell's position
//                   const rect = e.currentTarget.getBoundingClientRect()
//                   setTooltipPosition({
//                     top: rect.top + window.scrollY + 30, // 30px below the hovered date cell
//                     left: rect.left + window.scrollX, // Position relative to the viewport
//                   })
//                   setHoveredDay(day) // Set hovered day
//                 }}  
//                 onMouseLeave={() => setHoveredDay(null)} // Reset hovered day
//               >
//                 <div className="text-right font-medium">{day.getDate()}</div>
//                 <div className="mt-2 space-y-1">
//                   {dayAppointments.map((appointment) => (
//                     <div
//                       key={appointment.id}
//                       className={`text-xs p-1 rounded truncate ${
//                         appointment.status === "upcoming"
//                           ? "bg-blue-100 text-blue-800"
//                           : appointment.status === "completed"
//                           ? "bg-green-100 text-green-800"
//                           : "bg-red-100 text-red-800"
//                       }`}
//                     >
//                       {userRole === "doctor"
//                         ? appointment.patients?.full_name
//                         : appointment.doctors?.profiles?.full_name}
//                     </div>
//                   ))}
//                 </div>
//               </div>
//             )
//           })}
//         </div>

//         {/* Tooltip Display for Hovered Date */}
//         {hoveredDay && (
//           <div
//             className="absolute bg-white border p-4 shadow-lg rounded-md max-w-xs sm:max-w-sm md:max-w-md"
//             style={{
//               top: tooltipPosition.top, // Use calculated position
//               left: tooltipPosition.left, // Use calculated position
//               zIndex: 10,
//             }}
//           >
//             <p className="font-bold">{hoveredDay.toDateString()}</p>
//             {getAppointmentsForDay(hoveredDay).map((appointment) => (
//               <div key={appointment.id} className="text-sm">
//                 <p><strong>Time:</strong> {appointment.appointmentTime}</p>
//                 <p><strong>Doctor:</strong> {appointment.doctors?.profiles.full_name}</p>
//                 <p><strong>Diseases:</strong> 
//                   {appointment.diseases && appointment.diseases.length > 0 ? (
//                     <ul className="list-disc pl-5">
//                       {appointment.diseases.map((disease, index) => (
//                         <li key={index}>{disease}</li>
//                       ))}
//                     </ul>
//                   ) : (
//                     <span>No diseases listed</span>
//                   )}
//                 </p>
//               </div>
//             ))}
//           </div>
//         )}
//       </CardContent>
//     </Card>
//   )
// }

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface Appointment {
  id: string
  title: string
  appointmentDate: string
  appointmentTime: string
  status: "upcoming" | "completed" | "cancelled"
  patients?: { full_name: string }
  doctors?: { profiles: { full_name: string } }
  diseases?: string[]
}

interface AppointmentCalendarProps {
  appointments: Appointment[]
  userRole: "doctor" | "patient"
}

export default function AppointmentCalendar({ appointments, userRole }: AppointmentCalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [hoveredDay, setHoveredDay] = useState<Date | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState<{ top: number; left: number }>({ top: 0, left: 0 })

  const getDaysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate()
  const getFirstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay()
  const formatMonthYear = (date: Date) => date.toLocaleDateString("en-US", { month: "long", year: "numeric" })
  const isSameDay = (d1: Date, d2: Date) =>
    d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate()
  const isToday = (date: Date) => isSameDay(date, new Date())
  const parseDate = (s: string) => new Date(s)

  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1))
  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1))
  const goToToday = () => setCurrentDate(new Date())

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()
  const daysInMonth = getDaysInMonth(year, month)
  const firstDayOfMonth = getFirstDayOfMonth(year, month)

  const days: (Date | null)[] = []
  for (let i = 0; i < firstDayOfMonth; i++) days.push(null)
  for (let i = 1; i <= daysInMonth; i++) days.push(new Date(year, month, i))

  const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  const getAppointmentsForDay = (day: Date | null) =>
    day
      ? appointments.filter((appt) => {
          const date = parseDate(appt.appointmentDate)
          return isSameDay(date, day)
        })
      : []

  return (
    <Card className="relative rounded-xl shadow border border-blue-100 bg-gradient-to-br from-blue-50 to-green-50">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-teal-800">{formatMonthYear(currentDate)}</h2>
          <div className="flex space-x-2">
            <Button className="rounded-xl text-teal-700 border-teal-300 hover:bg-green-100" variant="outline" size="sm" onClick={goToToday}>
              Today
            </Button>
            <div className="flex">
              <Button className="rounded-xl text-teal-700 border-teal-300 hover:bg-green-100" variant="outline" size="icon" onClick={prevMonth}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button className="rounded-xl text-teal-700 border-teal-300 hover:bg-green-100" variant="outline" size="icon" onClick={nextMonth}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Calendar Header */}
        <div className="grid grid-cols-7 gap-px bg-teal-100 rounded overflow-hidden">
          {daysOfWeek.map((day) => (
            <div key={day} className="bg-white p-2 text-center font-semibold text-blue-800 border border-blue-100">
              {day}
            </div>
          ))}

          {/* Calendar Days */}
          {days.map((day, index) => {
            if (!day) {
              return <div key={`empty-${index}`} className="bg-white p-2 min-h-[100px] border border-blue-50"></div>
            }

            const appointments = getAppointmentsForDay(day)
            const isCurrentDay = isToday(day)

            return (
              <div
                key={day.toString()}
                className={`p-2 min-h-[100px] cursor-pointer border border-blue-50 ${
                  isCurrentDay ? "bg-blue-100" : "bg-white hover:bg-green-50"
                } transition-all duration-150`}
                onMouseEnter={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect()
                  setTooltipPosition({
                    top: rect.top + window.scrollY + 30,
                    left: rect.left + window.scrollX,
                  })
                  setHoveredDay(day)
                }}
                onMouseLeave={() => setHoveredDay(null)}
              >
                <div className="text-right font-semibold text-teal-900">{day.getDate()}</div>
                <div className="mt-2 space-y-1">
                  {appointments.map((appointment) => (
                    <div
                      key={appointment.id}
                      className={`text-xs p-1 rounded truncate font-medium ${
                        appointment.status === "upcoming"
                          ? "bg-blue-100 text-blue-800"
                          : appointment.status === "completed"
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {userRole === "doctor"
                        ? appointment.patients?.full_name
                        : appointment.doctors?.profiles?.full_name}
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </div>

        {/* Tooltip */}
        {hoveredDay && (
          <div
            className="absolute bg-white border border-blue-200 p-4 shadow-xl rounded-md max-w-xs z-50"
            style={{ top: tooltipPosition.top, left: tooltipPosition.left }}
          >
            <p className="font-bold text-blue-700">{hoveredDay.toDateString()}</p>
            {getAppointmentsForDay(hoveredDay).map((appointment) => (
              <div key={appointment.id} className="text-sm mt-2 space-y-1">
                <p><strong>Time:</strong> {appointment.appointmentTime}</p>
                <p><strong>Doctor:</strong> {appointment.doctors?.profiles.full_name}</p>
                <p><strong>Diseases:</strong>{" "}
                  {appointment.diseases?.length ? (
                    <ul className="list-disc pl-5">
                      {appointment.diseases.map((disease, i) => (
                        <li key={i}>{disease}</li>
                      ))}
                    </ul>
                  ) : (
                    <span>No diseases listed</span>
                  )}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

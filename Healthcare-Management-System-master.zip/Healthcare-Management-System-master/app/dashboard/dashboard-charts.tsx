// "use client"

// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import {
//   ResponsiveContainer,
//   BarChart,
//   Bar,
//   XAxis,
//   YAxis,
//   CartesianGrid,
//   Tooltip,
//   Legend,
//   LineChart,
//   Line,
// } from "recharts"

// interface DashboardChartsProps {
//   userRole: string
// }

// export function DashboardCharts({ userRole }: DashboardChartsProps) {
//   // Sample data for doctor's dashboard
//   const doctorData = [
//     { name: "Jan", appointments: 45, patients: 30 },
//     { name: "Feb", appointments: 52, patients: 35 },
//     { name: "Mar", appointments: 48, patients: 32 },
//     { name: "Apr", appointments: 61, patients: 40 },
//     { name: "May", appointments: 55, patients: 37 },
//     { name: "Jun", appointments: 67, patients: 45 },
//   ]

//   // Sample data for patient's dashboard
//   const patientHealthData = [
//     { name: "Jan", bloodPressure: 120, weight: 70 },
//     { name: "Feb", bloodPressure: 118, weight: 69 },
//     { name: "Mar", bloodPressure: 122, weight: 71 },
//     { name: "Apr", bloodPressure: 119, weight: 70 },
//     { name: "May", bloodPressure: 121, weight: 72 },
//     { name: "Jun", bloodPressure: 120, weight: 71 },
//   ]

//   return (
//     <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-2">
//       {userRole === "doctor" ? (
//         <>
//           <Card className="rounded-xl">
//             <CardHeader>
//               <CardTitle>Appointment Statistics</CardTitle>
//               <CardDescription>Monthly appointment trends</CardDescription>
//             </CardHeader>
//             <CardContent className="px-2">
//               <div className="h-[300px]">
//                 <ResponsiveContainer width="100%" height="100%">
//                   <BarChart data={doctorData}>
//                     <CartesianGrid strokeDasharray="3 3" />
//                     <XAxis dataKey="name" />
//                     <YAxis />
//                     <Tooltip />
//                     <Legend />
//                     <Bar dataKey="appointments" fill="#8884d8" name="Appointments" />
//                   </BarChart>
//                 </ResponsiveContainer>
//               </div>
//             </CardContent>
//           </Card>
//           <Card className="rounded-xl">
//             <CardHeader>
//               <CardTitle>Patient Growth</CardTitle>
//               <CardDescription>Monthly new patient registrations</CardDescription>
//             </CardHeader>
//             <CardContent className="px-2">
//               <div className="h-[300px]">
//                 <ResponsiveContainer width="100%" height="100%">
//                   <LineChart data={doctorData}>
//                     <CartesianGrid strokeDasharray="3 3" />
//                     <XAxis dataKey="name" />
//                     <YAxis />
//                     <Tooltip />
//                     <Legend />
//                     <Line type="monotone" dataKey="patients" stroke="#82ca9d" name="New Patients" />
//                   </LineChart>
//                 </ResponsiveContainer>
//               </div>
//             </CardContent>
//           </Card>
//         </>
//       ) : (
//         <>
//           <Card className="rounded-xl">
//             <CardHeader>
//               <CardTitle>Blood Pressure</CardTitle>
//               <CardDescription>Monthly blood pressure readings</CardDescription>
//             </CardHeader>
//             <CardContent className="px-2">
//               <div className="h-[300px]">
//                 <ResponsiveContainer width="100%" height="100%">
//                   <LineChart data={patientHealthData}>
//                     <CartesianGrid strokeDasharray="3 3" />
//                     <XAxis dataKey="name" />
//                     <YAxis />
//                     <Tooltip />
//                     <Legend />
//                     <Line type="monotone" dataKey="bloodPressure" stroke="#8884d8" name="Blood Pressure" />
//                   </LineChart>
//                 </ResponsiveContainer>
//               </div>
//             </CardContent>
//           </Card>
//           <Card className="rounded-xl">
//             <CardHeader>
//               <CardTitle>Weight Tracking</CardTitle>
//               <CardDescription>Monthly weight measurements (kg)</CardDescription>
//             </CardHeader>
//             <CardContent className="px-2">
//               <div className="h-[300px]">
//                 <ResponsiveContainer width="100%" height="100%">
//                   <LineChart data={patientHealthData}>
//                     <CartesianGrid strokeDasharray="3 3" />
//                     <XAxis dataKey="name" />
//                     <YAxis />
//                     <Tooltip />
//                     <Legend />
//                     <Line type="monotone" dataKey="weight" stroke="#82ca9d" name="Weight (kg)" />
//                   </LineChart>
//                 </ResponsiveContainer>
//               </div>
//             </CardContent>
//           </Card>
//         </>
//       )}
//     </div>
//   )
// }
"use client"

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
} from "recharts"

interface DashboardChartsProps {
  userRole: string
}

interface DoctorAvailability {
  name: string
  specialty: string
  nextAvailable: string
  status: "Available" | "Unavailable"
}

export default function DashboardCharts({ userRole }: DashboardChartsProps) {
  // Sample data for doctor's dashboard
  const doctorData = [
    { name: "Jan", appointments: 45, patients: 30 },
    { name: "Feb", appointments: 52, patients: 35 },
    { name: "Mar", appointments: 48, patients: 32 },
    { name: "Apr", appointments: 61, patients: 40 },
    { name: "May", appointments: 55, patients: 37 },
    { name: "Jun", appointments: 67, patients: 45 },
  ]

  // Sample data for patient's dashboard
  const patientHealthData = [
    { name: "Jan", bloodPressure: 120, weight: 70 },
    { name: "Feb", bloodPressure: 118, weight: 69 },
    { name: "Mar", bloodPressure: 122, weight: 71 },
    { name: "Apr", bloodPressure: 119, weight: 70 },
    { name: "May", bloodPressure: 121, weight: 72 },
    { name: "Jun", bloodPressure: 120, weight: 71 },
  ]

  // Randomly generated doctor availability
  const availability: DoctorAvailability[] = [
    {
      name: "Dr. Manoj Smith",
      specialty: "Radiologist",
      nextAvailable: "12 Jun 2025, 09:00–10:00",
      status: "Available",
    },
    {
      name: "Dr. Aditi Sharma",
      specialty: "Cardiologist",
      nextAvailable: "14 Jun 2025, 11:00–12:00",
      status: "Unavailable",
    },
    {
      name: "Dr. Arjun Singh",
      specialty: "Otolaryngologist",
      nextAvailable: "15 Jun 2025, 13:00–14:00",
      status: "Available",
    },
    {
      name: "Dr. Meera Joshi",
      specialty: "General Physician",
      nextAvailable: "16 Jun 2025, 10:30–11:30",
      status: "Available",
    },
  ]

  return (
    <div className="space-y-6">
      {/* Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {userRole === "doctor" ? (
          <>
            <Card className="rounded-xl shadow-md">
              <CardHeader>
                <CardTitle>Appointment Statistics</CardTitle>
                <CardDescription>Monthly appointment trends</CardDescription>
              </CardHeader>
              <CardContent className="p-4">
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={doctorData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="appointments" fill="#8884d8" name="Appointments" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card className="rounded-xl shadow-md">
              <CardHeader>
                <CardTitle>Patient Growth</CardTitle>
                <CardDescription>Monthly new patient registrations</CardDescription>
              </CardHeader>
              <CardContent className="p-4">
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={doctorData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="patients" stroke="#82ca9d" name="New Patients" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </>
        ) : (
          <>
            <Card className="rounded-xl shadow-md">
              <CardHeader>
                <CardTitle>Blood Pressure</CardTitle>
                <CardDescription>Monthly blood pressure readings</CardDescription>
              </CardHeader>
              <CardContent className="p-4">
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={patientHealthData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="bloodPressure" stroke="#8884d8" name="Blood Pressure" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            <Card className="rounded-xl shadow-md">
              <CardHeader>
                <CardTitle>Weight Tracking</CardTitle>
                <CardDescription>Monthly weight measurements (kg)</CardDescription>
              </CardHeader>
              <CardContent className="p-4">
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={patientHealthData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="weight" stroke="#82ca9d" name="Weight (kg)" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* Doctor Availability: responsive mini-cards */}
      <Card className="rounded-xl shadow-md">
  <CardHeader>
    <CardTitle>Doctor Availability</CardTitle>
    <CardDescription>Next available slots</CardDescription>
  </CardHeader>
  <CardContent className="p-4">
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {availability.map((doc, index) => (
        <div
          key={doc.name}
          className="flex flex-col justify-between p-4 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg shadow transition-transform hover:scale-[1.02] hover:shadow-md animate-fade-in-up"
          style={{ animationDelay: `${index * 0.1}s` }}
        >
          <div>
            <p className="font-semibold text-blue-900">{doc.name}</p>
            <p className="text-sm text-blue-700">{doc.specialty}</p>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-700">{doc.nextAvailable}</p>
            <span
              className={`inline-block mt-2 rounded-full px-2 py-1 text-xs font-semibold ${
                doc.status === "Available"
                  ? "bg-green-200 text-green-900"
                  : "bg-red-200 text-red-800"
              }`}
            >
              {doc.status}
            </span>
          </div>
        </div>
      ))}
    </div>
  </CardContent>
</Card>

    </div>
  )
}

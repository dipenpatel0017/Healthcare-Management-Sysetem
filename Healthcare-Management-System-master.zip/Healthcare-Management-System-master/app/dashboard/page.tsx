
"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { formatDate } from "@/lib/utils"
import DashboardLayout from "@/components/layout/dashboard-layout"
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card"
import { Calendar, Users, FileText, CreditCard } from "lucide-react"
import {
  getCurrentUser,
  getProfileById,
  getAppointmentsByDoctorId,
  getAppointmentsByPatientId,
  getProfiles,
} from "@/lib/browser-storage"
import DashboardCharts from "./dashboard-charts"

interface DoctorAvailability {
  name: string
  specialty: string
  nextAvailable: string
  status: "Available" | "Unavailable"
}

export default function DashboardPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [profileData, setProfileData] = useState<any>(null)
  const [appointments, setAppointments] = useState<any[]>([])
  const [stats, setStats] = useState<any>({})

  // Sample availability
  const availability: DoctorAvailability[] = [
    { name: "Dr. Cara Stevens", specialty: "Radiologist", nextAvailable: "12 Jun 2025, 09:00–10:00", status: "Available" },
    { name: "Dr. John Doe", specialty: "Cardiologist", nextAvailable: "14 Jun 2025, 11:00–12:00", status: "Unavailable" },
    { name: "Dr. Air Satou", specialty: "Otolaryngologist", nextAvailable: "15 Jun 2025, 13:00–14:00", status: "Available" },
    { name: "Dr. Angelica Ramos", specialty: "Dentist", nextAvailable: "16 Jun 2025, 10:30–11:30", status: "Unavailable" },
  ]

  useEffect(() => {
    const fetchData = async () => {
      const user = getCurrentUser()
      if (!user) return router.push("/")

      const profile = getProfileById(user.id)
      if (!profile) return router.push("/")

      setProfileData(profile)

      const userAppointments =
        profile.role === "doctor"
          ? getAppointmentsByDoctorId(user.id)
          : getAppointmentsByPatientId(user.id)

      const allProfiles = getProfiles()
      const enriched = userAppointments.map((apt) => {
        if (profile.role === "doctor") {
          const p = allProfiles.find((x) => x.id === apt.patientId)
          return { ...apt, label: p?.fullName ?? "Unknown Patient" }
        } else {
          const d = allProfiles.find((x) => x.id === apt.doctorId)
          return { ...apt, label: d?.fullName ?? "Unknown Doctor" }
        }
      })
      setAppointments(enriched)

      if (profile.role === "doctor") {
        const uniqueIds = new Set(userAppointments.map((a) => a.patientId))
        setStats({ appointments: userAppointments.length, patients: uniqueIds.size, surgeries: 3, roomVisits: 12 })
      } else {
        setStats({ appointments: userAppointments.length, reports: 3, expenditure: 420.0 })
      }

      setLoading(false)
    }
    fetchData()
  }, [router])

  if (loading || !profileData) {
    return <div className="flex items-center justify-center h-screen">Loading…</div>
  }

  return (
    <DashboardLayout userRole={profileData.role} userName={profileData.fullName} userAvatar={profileData.avatarUrl}>
      <div className="p-6 space-y-8">
        {/* Welcome */}
        <div>
          <h2 className="text-3xl font-bold">Welcome back, {profileData.fullName}!</h2>
          <p className="text-muted-foreground">
            Here’s an overview of your {profileData.role === "doctor" ? "practice" : "health records and appointments"}.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {(profileData.role === "doctor"
            ? ["appointments", "patients", "surgeries", "roomVisits"]
            : ["appointments", "expenditure", "reports"]
          ).map((key) => (
            <Card key={key} className="rounded-xl shadow-md">
              <CardHeader className="flex justify-between">
                <CardTitle className="text-sm capitalize">{key}</CardTitle>
                {{
                  appointments: <Calendar className="h-4 w-4 text-muted-foreground" />,
                  patients: <Users className="h-4 w-4 text-muted-foreground" />,
                  surgeries: <FileText className="h-4 w-4 text-muted-foreground" />,
                  roomVisits: <Users className="h-4 w-4 text-muted-foreground" />,
                  expenditure: <CreditCard className="h-4 w-4 text-muted-foreground" />,
                  reports: <FileText className="h-4 w-4 text-muted-foreground" />,
                }[key]}
              </CardHeader>
              <CardContent>
                <span className="text-2xl font-bold">
                  {key === "expenditure" ? `₹${stats[key].toFixed(2)}` : stats[key]}
                  {["appointments", "surgeries", "roomVisits"].includes(key) && "+"}
                </span>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts */}
        <DashboardCharts userRole={profileData.role} />

        {/* Appointments / Medications */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Appointments List */}
          <Card className="rounded-xl shadow-md">
            <CardHeader>
              <CardTitle>Appointments</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {appointments.length ? (
                appointments.slice(0, 5).map((apt) => (
                  <div key={apt.id} className="flex justify-between items-center border-b pb-2">
                    <div>
                      <p className="font-medium">{apt.label}</p>
                      <p className="text-sm text-muted-foreground">{formatDate(apt.appointmentDate)}</p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      apt.status === "upcoming" ? "bg-blue-100 text-blue-800"
                      : apt.status === "completed" ? "bg-green-100 text-green-800"
                      : "bg-red-100 text-red-800"
                    }`}>
                      {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">No appointments.</p>
              )}
            </CardContent>
          </Card>

          {/* Recent Patients or Upcoming Medications */}
          <Card className="rounded-xl shadow-md">
            <CardHeader>
              <CardTitle>
                {profileData.role === "doctor" ? "Recent Patients" : "Upcoming Medications"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {profileData.role === "doctor" ? (
                Array.from(new Set(appointments.map((a) => a.label))).slice(0, 5).map((name) => (
                  <div key={name} className="flex items-center border-b pb-2">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                      <span className="font-medium text-blue-600">{name[0]}</span>
                    </div>
                    <div>
                      <p className="font-medium">{name}</p>
                      <p className="text-sm text-muted-foreground">Last visit: recently</p>
                    </div>
                  </div>
                ))
              ) : (
                [
                  ["Lisinopril 10mg", "Once daily, with food", "Morning"],
                  ["Aspirin 81mg", "Once daily", "Evening"],
                  ["Vitamin D3 1000IU", "Once daily, with meal", "Afternoon"],
                ].map(([med, desc, tag]) => (
                  <div key={med} className="flex justify-between items-center border-b pb-2">
                    <div>
                      <p className="font-medium">{med}</p>
                      <p className="text-sm text-muted-foreground">{desc}</p>
                    </div>
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {tag}
                    </span>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>

      </div>
    </DashboardLayout>
  )
}

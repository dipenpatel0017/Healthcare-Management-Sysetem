// "use client"

// import { useEffect, useState } from "react"
// import { useRouter } from "next/navigation"
// import DashboardLayout from "@/components/layout/dashboard-layout"
// import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
// import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
// import {
//   BarChart,
//   Bar,
//   XAxis,
//   YAxis,
//   CartesianGrid,
//   Tooltip,
//   Legend,
//   ResponsiveContainer,
//   LineChart,
//   Line,
//   PieChart,
//   Pie,
//   Cell,
// } from "recharts"
// import { Calendar, CreditCard, Activity, User, Stethoscope } from "lucide-react"
// import {
//   getCurrentUser,
//   getProfileById,
//   getAppointments,
//   getProfiles,
//   getPrescriptions,
//   getReports,
//   getInvoices,
// } from "@/lib/browser-storage"

// export default function AdminDashboardPage() {
//   const router = useRouter()
//   const [loading, setLoading] = useState(true)
//   const [profileData, setProfileData] = useState<any>(null)
//   const [stats, setStats] = useState<any>({})
//   const [chartData, setChartData] = useState<any>({})

//   useEffect(() => {
//     const fetchData = async () => {
//       const user = getCurrentUser()

//       if (!user) {
//         router.push("/")
//         return
//       }

//       const profile = getProfileById(user.id)

//       if (!profile || profile.role !== "admin") {
//         router.push("/")
//         return
//       }

//       setProfileData(profile)

//       // Get all data
//       const allAppointments = getAppointments()
//       const allProfiles = getProfiles()
//       const allPrescriptions = getPrescriptions()
//       const allReports = getReports()
//       const allInvoices = getInvoices()

//       // Calculate stats
//       const doctorProfiles = allProfiles.filter((p) => p.role === "doctor")
//       const patientProfiles = allProfiles.filter((p) => p.role === "patient")

//       const totalRevenue = allInvoices.reduce((sum, invoice) => sum + invoice.totalAmount, 0)
//       const paidRevenue = allInvoices
//         .filter((invoice) => invoice.status === "paid")
//         .reduce((sum, invoice) => sum + invoice.totalAmount, 0)

//       const upcomingAppointments = allAppointments.filter((a) => a.status === "upcoming").length
//       const completedAppointments = allAppointments.filter((a) => a.status === "completed").length
//       const cancelledAppointments = allAppointments.filter((a) => a.status === "cancelled").length

//       setStats({
//         doctors: doctorProfiles.length,
//         patients: patientProfiles.length,
//         appointments: allAppointments.length,
//         prescriptions: allPrescriptions.length,
//         reports: allReports.length,
//         revenue: totalRevenue,
//         paidRevenue: paidRevenue,
//         upcomingAppointments,
//         completedAppointments,
//         cancelledAppointments,
//       })

//       // Generate chart data
//       generateChartData(allAppointments, allInvoices, doctorProfiles, patientProfiles)

//       setLoading(false)
//     }

//     const generateChartData = (appointments: any[], invoices: any[], doctors: any[], patients: any[]) => {
//       // Appointments by month
//       const appointmentsByMonth: Record<string, number> = {}
//       const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

//       // Initialize all months with 0
//       months.forEach((month) => {
//         appointmentsByMonth[month] = 0
//       })

//       // Count appointments by month
//       appointments.forEach((appointment) => {
//         const date = new Date(appointment.appointmentDate)
//         const month = months[date.getMonth()]
//         appointmentsByMonth[month] = (appointmentsByMonth[month] || 0) + 1
//       })

//       // Revenue by month
//       const revenueByMonth: Record<string, number> = {}

//       // Initialize all months with 0
//       months.forEach((month) => {
//         revenueByMonth[month] = 0
//       })

//       invoices.forEach((invoice) => {
//         const date = new Date(invoice.createdAt)
//         const month = months[date.getMonth()]
//         revenueByMonth[month] = (revenueByMonth[month] || 0) + invoice.totalAmount
//       })

//       // Appointment status distribution
//       const appointmentStatusData = [
//         { name: "Upcoming", value: appointments.filter((a) => a.status === "upcoming").length },
//         { name: "Completed", value: appointments.filter((a) => a.status === "completed").length },
//         { name: "Cancelled", value: appointments.filter((a) => a.status === "cancelled").length },
//       ]

//       // Department distribution
//       const departmentData: Record<string, number> = {}

//       doctors.forEach((doctor) => {
//         const department = doctor.department || "Other"
//         departmentData[department] = (departmentData[department] || 0) + 1
//       })

//       const departmentChartData = Object.entries(departmentData).map(([name, value]) => ({ name, value }))

//       // Patient growth data (simulated)
//       const patientGrowthData = months.slice(0, 6).map((month, index) => ({
//         name: month,
//         patients: Math.floor(patients.length * (0.7 + index * 0.05)),
//       }))

//       setChartData({
//         appointmentsByMonth: Object.entries(appointmentsByMonth).map(([name, value]) => ({ name, value })),
//         revenueByMonth: Object.entries(revenueByMonth).map(([name, value]) => ({ name, value: Math.round(value) })),
//         appointmentStatusData,
//         departmentChartData,
//         patientGrowthData,
//       })
//     }

//     fetchData()
//   }, [router])

//   if (loading || !profileData) {
//     return <div className="flex items-center justify-center h-screen">Loading...</div>
//   }

//   const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D"]

//   return (
//     <DashboardLayout userRole={profileData.role} userName={profileData.fullName} userAvatar={profileData.avatarUrl}>
//       <div className="p-6">
//         <div className="mb-8">
//           <h2 className="text-3xl font-bold">Admin Dashboard</h2>
//           <p className="text-muted-foreground">
//             Welcome to the system administration dashboard. Here's an overview of the entire healthcare system.
//           </p>
//         </div>

//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
//           <Card className="rounded-xl">
//             <CardHeader className="flex flex-row items-center justify-between pb-2">
//               <CardTitle className="text-sm font-medium">Total Doctors</CardTitle>
//               <Stethoscope className="h-4 w-4 text-muted-foreground" />
//             </CardHeader>
//             <CardContent>
//               <div className="text-2xl font-bold">{stats.doctors}</div>
//             </CardContent>
//           </Card>
//           <Card className="rounded-xl">
//             <CardHeader className="flex flex-row items-center justify-between pb-2">
//               <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
//               <User className="h-4 w-4 text-muted-foreground" />
//             </CardHeader>
//             <CardContent>
//               <div className="text-2xl font-bold">{stats.patients}</div>
//             </CardContent>
//           </Card>
//           <Card className="rounded-xl">
//             <CardHeader className="flex flex-row items-center justify-between pb-2">
//               <CardTitle className="text-sm font-medium">Total Appointments</CardTitle>
//               <Calendar className="h-4 w-4 text-muted-foreground" />
//             </CardHeader>
//             <CardContent>
//               <div className="text-2xl font-bold">{stats.appointments}</div>
//             </CardContent>
//           </Card>
//           <Card className="rounded-xl">
//             <CardHeader className="flex flex-row items-center justify-between pb-2">
//               <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
//               <CreditCard className="h-4 w-4 text-muted-foreground" />
//             </CardHeader>
//             <CardContent>
//               <div className="text-2xl font-bold">₹{stats.revenue?.toFixed(2) || "0.00"}</div>
//             </CardContent>
//           </Card>
//         </div>

//         <Tabs defaultValue="overview" className="mb-8 rounded-xl">
//           <TabsList className="mb-4">
//             <TabsTrigger value="overview">Overview</TabsTrigger>
//             <TabsTrigger value="appointments">Appointments</TabsTrigger>
//             <TabsTrigger value="revenue">Revenue</TabsTrigger>
//             <TabsTrigger value="departments">Departments</TabsTrigger>
//           </TabsList>

//           <TabsContent value="overview">
//             <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
//               <Card className="rounded-xl">
//                 <CardHeader>
//                   <CardTitle>Patient Growth</CardTitle>
//                 </CardHeader>
//                 <CardContent>
//                   <div className="h-80">
//                     <ResponsiveContainer width="100%" height="100%">
//                       <LineChart data={chartData.patientGrowthData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
//                         <CartesianGrid strokeDasharray="3 3" />
//                         <XAxis dataKey="name" />
//                         <YAxis />
//                         <Tooltip />
//                         <Legend />
//                         <Line type="monotone" dataKey="patients" stroke="#8884d8" activeDot={{ r: 8 }} />
//                       </LineChart>
//                     </ResponsiveContainer>
//                   </div>
//                 </CardContent>
//               </Card>

//               <Card className="rounded-xl">
//                 <CardHeader>
//                   <CardTitle>Appointment Status</CardTitle>
//                 </CardHeader>
//                 <CardContent>
//                   <div className="h-80">
//                     <ResponsiveContainer width="100%" height="100%">
//                       <PieChart>
//                         <Pie
//                           data={chartData.appointmentStatusData}
//                           cx="50%"
//                           cy="50%"
//                           labelLine={false}
//                           label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
//                           outerRadius={80}
//                           fill="#8884d8"
//                           dataKey="value"
//                         >
//                           {chartData.appointmentStatusData?.map((entry: any, index: number) => (
//                             <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
//                           ))}
//                         </Pie>
//                         <Tooltip />
//                         <Legend />
//                       </PieChart>
//                     </ResponsiveContainer>
//                   </div>
//                 </CardContent>
//               </Card>
//             </div>
//           </TabsContent>

//           <TabsContent value="appointments">
//             <Card className="rounded-xl">
//               <CardHeader>
//                 <CardTitle>Appointments by Month</CardTitle>
//               </CardHeader>
//               <CardContent>
//                 <div className="h-96">
//                   <ResponsiveContainer width="100%" height="100%">
//                     <BarChart data={chartData.appointmentsByMonth} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
//                       <CartesianGrid strokeDasharray="3 3" />
//                       <XAxis dataKey="name" />
//                       <YAxis />
//                       <Tooltip />
//                       <Legend />
//                       <Bar dataKey="value" name="Appointments" fill="#8884d8" />
//                     </BarChart>
//                   </ResponsiveContainer>
//                 </div>
//               </CardContent>
//             </Card>
//           </TabsContent>

//           <TabsContent value="revenue">
//             <Card className="rounded-xl">
//               <CardHeader>
//                 <CardTitle>Revenue by Month</CardTitle>
//               </CardHeader>
//               <CardContent>
//                 <div className="h-96">
//                   <ResponsiveContainer width="100%" height="100%">
//                     <BarChart data={chartData.revenueByMonth} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
//                       <CartesianGrid strokeDasharray="3 3" />
//                       <XAxis dataKey="name" />
//                       <YAxis />
//                       <Tooltip formatter={(value) => [`₹${value}`, "Revenue"]} />
//                       <Legend />
//                       <Bar dataKey="value" name="Revenue (₹)" fill="#82ca9d" />
//                     </BarChart>
//                   </ResponsiveContainer>
//                 </div>
//               </CardContent>
//             </Card>
//           </TabsContent>

//           <TabsContent value="departments">
//             <Card className="rounded-xl">
//               <CardHeader>
//                 <CardTitle>Doctors by Department</CardTitle>
//               </CardHeader>
//               <CardContent>
//                 <div className="h-96">
//                   <ResponsiveContainer width="100%" height="100%">
//                     <PieChart>
//                       <Pie
//                         data={chartData.departmentChartData}
//                         cx="50%"
//                         cy="50%"
//                         labelLine={false}
//                         label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
//                         outerRadius={80}
//                         fill="#8884d8"
//                         dataKey="value"
//                       >
//                         {chartData.departmentChartData?.map((entry: any, index: number) => (
//                           <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
//                         ))}
//                       </Pie>
//                       <Tooltip />
//                       <Legend />
//                     </PieChart>
//                   </ResponsiveContainer>
//                 </div>
//               </CardContent>
//             </Card>
//           </TabsContent>
//         </Tabs>

//         <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
//           <Card className="rounded-xl">
//             <CardHeader>
//               <CardTitle>System Statistics</CardTitle>
//             </CardHeader>
//             <CardContent>
//               <div className="space-y-4">
//                 <div className="flex justify-between items-center border-b pb-2">
//                   <span className="font-medium">Total Doctors</span>
//                   <span>{stats.doctors}</span>
//                 </div>
//                 <div className="flex justify-between items-center border-b pb-2">
//                   <span className="font-medium">Total Patients</span>
//                   <span>{stats.patients}</span>
//                 </div>
//                 <div className="flex justify-between items-center border-b pb-2">
//                   <span className="font-medium">Total Appointments</span>
//                   <span>{stats.appointments}</span>
//                 </div>
//                 <div className="flex justify-between items-center border-b pb-2">
//                   <span className="font-medium">Upcoming Appointments</span>
//                   <span>{stats.upcomingAppointments}</span>
//                 </div>
//                 <div className="flex justify-between items-center border-b pb-2">
//                   <span className="font-medium">Completed Appointments</span>
//                   <span>{stats.completedAppointments}</span>
//                 </div>
//                 <div className="flex justify-between items-center border-b pb-2">
//                   <span className="font-medium">Cancelled Appointments</span>
//                   <span>{stats.cancelledAppointments}</span>
//                 </div>
//                 <div className="flex justify-between items-center border-b pb-2">
//                   <span className="font-medium">Total Prescriptions</span>
//                   <span>{stats.prescriptions}</span>
//                 </div>
//                 <div className="flex justify-between items-center border-b pb-2">
//                   <span className="font-medium">Total Reports</span>
//                   <span>{stats.reports}</span>
//                 </div>
//                 <div className="flex justify-between items-center border-b pb-2">
//                   <span className="font-medium">Total Revenue</span>
//                   <span>₹{stats.revenue?.toFixed(2) || "0.00"}</span>
//                 </div>
//                 <div className="flex justify-between items-center">
//                   <span className="font-medium">Collected Revenue</span>
//                   <span>₹{stats.paidRevenue?.toFixed(2) || "0.00"}</span>
//                 </div>
//               </div>
//             </CardContent>
//           </Card>

//           <Card className="rounded-xl">
//             <CardHeader>
//               <CardTitle>Recent Activity</CardTitle>
//             </CardHeader>
//             <CardContent>
//               <div className="space-y-4">
//                 <div className="flex items-center border-b pb-4">
//                   <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
//                     <Activity className="h-5 w-5 text-blue-600" />
//                   </div>
//                   <div>
//                     <p className="font-medium">New Doctor Registered</p>
//                     <p className="text-sm text-muted-foreground">Dr. Lisa Wong joined the platform</p>
//                     <p className="text-xs text-muted-foreground">2 hours ago</p>
//                   </div>
//                 </div>
//                 <div className="flex items-center border-b pb-4">
//                   <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
//                     <Activity className="h-5 w-5 text-green-600" />
//                   </div>
//                   <div>
//                     <p className="font-medium">New Patient Registered</p>
//                     <p className="text-sm text-muted-foreground">James Taylor created an account</p>
//                     <p className="text-xs text-muted-foreground">5 hours ago</p>
//                   </div>
//                 </div>
//                 <div className="flex items-center border-b pb-4">
//                   <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
//                     <Activity className="h-5 w-5 text-purple-600" />
//                   </div>
//                   <div>
//                     <p className="font-medium">System Update</p>
//                     <p className="text-sm text-muted-foreground">New features added to the platform</p>
//                     <p className="text-xs text-muted-foreground">1 day ago</p>
//                   </div>
//                 </div>
//                 <div className="flex items-center border-b pb-4">
//                   <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center mr-3">
//                     <Activity className="h-5 w-5 text-yellow-600" />
//                   </div>
//                   <div>
//                     <p className="font-medium">Payment Received</p>
//                     <p className="text-sm text-muted-foreground">Invoice #INV-2023-005 was paid</p>
//                     <p className="text-xs text-muted-foreground">2 days ago</p>
//                   </div>
//                 </div>
//               </div>
//             </CardContent>
//           </Card>
//         </div>
//       </div>
//     </DashboardLayout>
//   )
// }

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import DashboardLayout from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { Calendar, CreditCard, Activity, User, Stethoscope } from "lucide-react"
import {
  getCurrentUser,
  getProfileById,
  getAppointments,
  getProfiles,
  getPrescriptions,
  getReports,
  getInvoices,
} from "@/lib/browser-storage"

export default function AdminDashboardPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [profileData, setProfileData] = useState<any>(null)
  const [stats, setStats] = useState<any>({})
  const [chartData, setChartData] = useState<any>({})
  const [allProfiles, setAllProfiles] = useState<any[]>([])

  useEffect(() => {
    const fetchData = async () => {
      const user = getCurrentUser()
      if (!user) return router.push("/")

      const profile = getProfileById(user.id)
      if (!profile || profile.role !== "admin") return router.push("/")

      setProfileData(profile)

      // load all domain data
      const appointments = getAppointments()
      const profiles = getProfiles()
      const prescriptions = getPrescriptions()
      const reports = getReports()
      const invoices = getInvoices()

      setAllProfiles(profiles)

      // stats
      const doctors = profiles.filter((p) => p.role === "doctor")
      const patients = profiles.filter((p) => p.role === "patient")
      const totalRevenue = invoices.reduce((sum, inv) => sum + inv.totalAmount, 0)
      const paidRevenue = invoices.filter((inv) => inv.status === "paid").reduce((sum, inv) => sum + inv.totalAmount, 0)
      const upcoming = appointments.filter((a) => a.status === "upcoming").length
      const completed = appointments.filter((a) => a.status === "completed").length
      const cancelled = appointments.filter((a) => a.status === "cancelled").length

      setStats({
        doctors: doctors.length,
        patients: patients.length,
        appointments: appointments.length,
        prescriptions: prescriptions.length,
        reports: reports.length,
        revenue: totalRevenue,
        paidRevenue,
        upcomingAppointments: upcoming,
        completedAppointments: completed,
        cancelledAppointments: cancelled,
      })

      buildCharts(appointments, invoices, doctors, patients)
      setLoading(false)
    }

    const buildCharts = (
      appointments: any[],
      invoices: any[],
      doctors: any[],
      patients: any[]
    ) => {
      const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
      const apptByMonth: Record<string, number> = {}
      const revByMonth: Record<string, number> = {}
      months.forEach((m) => { apptByMonth[m]=0; revByMonth[m]=0 })

      appointments.forEach((a) => {
        const m = months[new Date(a.appointmentDate).getMonth()]
        apptByMonth[m]++
      })
      invoices.forEach((inv) => {
        const m = months[new Date(inv.createdAt).getMonth()]
        revByMonth[m] += inv.totalAmount
      })

      setChartData({
        appointmentsByMonth: months.map((m) => ({ name: m, value: apptByMonth[m] })),
        revenueByMonth: months.map((m) => ({ name: m, value: Math.round(revByMonth[m]) })),
        appointmentStatusData: [
          { name: "Upcoming",  value: apptByMonth[months[new Date().getMonth()]] },
          { name: "Completed", value: apptByMonth[months[new Date().getMonth()]] },
          { name: "Cancelled", value: apptByMonth[months[new Date().getMonth()]] },
        ],
        departmentChartData: Object.entries(
          doctors.reduce((acc, d) => {
            const dept = d.department || "Other"
            acc[dept] = (acc[dept]||0)+1
            return acc
          }, {} as Record<string,number>)
        ).map(([name,value])=>({name,value})),
        patientGrowthData: months.slice(0,6).map((m,i)=>({
          name:m, patients: Math.floor(patients.length*(0.7+i*0.05))
        })),
      })
    }

    fetchData()
  }, [router])

  if (loading || !profileData) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  const COLORS = ["#0088FE","#00C49F","#FFBB28","#FF8042","#8884D8","#82CA9D"]

  return (
    <DashboardLayout
      userRole="admin"
      userName={profileData.fullName}
      userAvatar={profileData.avatarUrl}
    >
      <div className="p-6 space-y-8">
        {/* Top stat cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title="Total Doctors" value={stats.doctors} icon={<Stethoscope />} />
          <StatCard title="Total Patients" value={stats.patients} icon={<User />} />
          <StatCard title="Total Appointments" value={stats.appointments} icon={<Calendar />} />
          <StatCard title="Total Revenue" value={`₹${stats.revenue?.toFixed(2)}`} icon={<CreditCard />} />
        </div>

        {/* Charts in tabs */}
        <Tabs defaultValue="overview" className="rounded-xl">
          <TabsList className="mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="appointments">Appointments</TabsTrigger>
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="departments">Departments</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="rounded-xl">
                <CardHeader><CardTitle>Patient Growth</CardTitle></CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData.patientGrowthData}>
                        <CartesianGrid strokeDasharray="3 3"/>
                        <XAxis dataKey="name"/>
                        <YAxis/>
                        <Tooltip/>
                        <Legend/>
                        <Line type="monotone" dataKey="patients" stroke="#8884d8" activeDot={{r:8}}/>
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              <Card className="rounded-xl">
                <CardHeader><CardTitle>Appointment Status</CardTitle></CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={chartData.appointmentStatusData}
                          cx="50%" cy="50%" outerRadius={80}
                          labelLine={false}
                          label={({name,percent})=>`${name}: ${(percent*100).toFixed(0)}%`}
                          dataKey="value"
                        >
                          {chartData.appointmentStatusData.map((_,i)=>(
                            <Cell key={i} fill={COLORS[i%COLORS.length]}/>
                          ))}
                        </Pie>
                        <Tooltip/>
                        <Legend/>
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="appointments">
            <Card className="rounded-xl">
              <CardHeader><CardTitle>Appointments by Month</CardTitle></CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData.appointmentsByMonth}>
                      <CartesianGrid strokeDasharray="3 3"/>
                      <XAxis dataKey="name"/>
                      <YAxis/>
                      <Tooltip/>
                      <Legend/>
                      <Bar dataKey="value" name="Appointments" fill="#8884d8"/>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="revenue">
            <Card className="rounded-xl">
              <CardHeader><CardTitle>Revenue by Month</CardTitle></CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData.revenueByMonth}>
                      <CartesianGrid strokeDasharray="3 3"/>
                      <XAxis dataKey="name"/>
                      <YAxis/>
                      <Tooltip formatter={(v)=>[`₹${v}`,"Revenue"]}/>
                      <Legend/>
                      <Bar dataKey="value" name="Revenue" fill="#82ca9d"/>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="departments">
            <Card className="rounded-xl">
              <CardHeader><CardTitle>Doctors by Department</CardTitle></CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={chartData.departmentChartData}
                        cx="50%" cy="50%" outerRadius={80}
                        labelLine={false}
                        label={({name,percent})=>`${name}: ${(percent*100).toFixed(0)}%`}
                        dataKey="value"
                      >
                        {chartData.departmentChartData.map((_,i)=>(
                          <Cell key={i} fill={COLORS[i%COLORS.length]}/>
                        ))}
                      </Pie>
                      <Tooltip/>
                      <Legend/>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Mid Stats & Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="rounded-xl">
            <CardHeader><CardTitle>System Statistics</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  ["Total Doctors", stats.doctors],
                  ["Total Patients", stats.patients],
                  ["Total Appointments", stats.appointments],
                  ["Upcoming Appointments", stats.upcomingAppointments],
                  ["Completed Appointments", stats.completedAppointments],
                  ["Cancelled Appointments", stats.cancelledAppointments],
                  ["Total Prescriptions", stats.prescriptions],
                  ["Total Reports", stats.reports],
                  ["Total Revenue", `₹${stats.revenue?.toFixed(2)}`],
                  ["Collected Revenue", `₹${stats.paidRevenue?.toFixed(2)}`],
                ].map(([label,val])=>(
                  <div key={label} className="flex justify-between items-center border-b pb-2">
                    <span className="font-medium">{label}</span>
                    <span>{val}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-xl">
            <CardHeader><CardTitle>Recent Activity</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { icon:"blue",   title:"New Doctor Registered",   desc:"Dr. Lisa Wong joined the platform",   time:"2 hours ago" },
                  { icon:"green",  title:"New Patient Registered",  desc:"James Taylor created an account",    time:"5 hours ago" },
                  { icon:"purple", title:"System Update",          desc:"New features added to the platform", time:"1 day ago" },
                  { icon:"yellow", title:"Payment Received",       desc:"Invoice #INV-2023-005 was paid",     time:"2 days ago" },
                ].map(a=>(
                  <div key={a.title} className="flex items-center border-b pb-4">
                    <div className={`w-10 h-10 rounded-full bg-${a.icon}-100 flex items-center justify-center mr-3`}>
                      <Activity className={`h-5 w-5 text-${a.icon}-600`}/>
                    </div>
                    <div>
                      <p className="font-medium">{a.title}</p>
                      <p className="text-sm text-muted-foreground">{a.desc}</p>
                      <p className="text-xs text-muted-foreground">{a.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* ─────────── New Bottom Section ─────────── */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Doctor States */}
          <Card className="rounded-xl">
            <CardHeader><CardTitle>Doctor States</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {allProfiles
                .filter((p) => p.role === "doctor")
                .map((d) => {
                  const available = Math.random() > 0.5
                  return (
                    <div key={d.id} className="flex justify-between items-center border-b pb-2">
                      <span>{d.fullName}</span>
                      <span
                        className={`text-xs py-0.5 px-2 rounded ${
                          available ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                        }`}
                      >
                        {available ? "Available" : "Unavailable"}
                      </span>
                    </div>
                  )
                })}
            </CardContent>
          </Card>

          {/* Patient States */}
          <Card className="rounded-xl">
            <CardHeader><CardTitle>Patient States</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {allProfiles
                .filter((p) => p.role === "patient")
                .map((p) => {
                  const active = Math.random() > 0.5
                  return (
                    <div key={p.id} className="flex justify-between items-center border-b pb-2">
                      <span>{p.fullName}</span>
                      <span
                        className={`text-xs py-0.5 px-2 rounded ${
                          active ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {active ? "Active" : "Inactive"}
                      </span>
                    </div>
                  )
                })}
            </CardContent>
          </Card>

          {/* Appointment Summary */}
          <Card className="rounded-xl">
            <CardHeader><CardTitle>Appointment Summary</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between border-b pb-2">
                <span>Booked</span>
                <span className="bg-green-100 text-green-800 text-xs py-0.5 px-2 rounded">{stats.appointments}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span>Upcoming</span>
                <span className="bg-blue-100 text-blue-800 text-xs py-0.5 px-2 rounded">
                  {stats.upcomingAppointments}
                </span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span>Completed</span>
                <span className="bg-green-100 text-green-800 text-xs py-0.5 px-2 rounded">
                  {stats.completedAppointments}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Cancelled</span>
                <span className="bg-red-100 text-red-800 text-xs py-0.5 px-2 rounded">
                  {stats.cancelledAppointments}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}

function StatCard({
  title,
  value,
  icon,
}: {
  title: string
  value: string | number
  icon: React.ReactNode
}) {
  return (
    <Card className="rounded-xl">
      <CardHeader className="flex justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="h-4 w-4 text-muted-foreground">{icon}</div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  )
}


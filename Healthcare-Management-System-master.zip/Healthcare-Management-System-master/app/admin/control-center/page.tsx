// "use client"

// import type React from "react"

// import { useEffect, useState } from "react"
// import { useRouter } from "next/navigation"
// import DashboardLayout from "@/components/layout/dashboard-layout"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
// import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
// import { toast } from "@/components/ui/use-toast"
// import { UserPlus, RefreshCw, Copy } from "lucide-react"
// import { getCurrentUser, getProfileById, getProfiles, addUser, addProfile, generateId } from "@/lib/browser-storage"

// export default function AdminControlCenterPage() {
//   const router = useRouter()
//   const [loading, setLoading] = useState(true)
//   const [profileData, setProfileData] = useState<any>(null)
//   const [doctors, setDoctors] = useState<any[]>([])
//   const [newDoctorData, setNewDoctorData] = useState({
//     fullName: "",
//     email: "",
//     specialization: "",
//     department: "",
//   })
//   const [generatedCredentials, setGeneratedCredentials] = useState<{
//     email: string
//     password: string
//   } | null>(null)
//   const [isCreatingDoctor, setIsCreatingDoctor] = useState(false)

//   useEffect(() => {
//     const fetchData = async () => {
//       const user = getCurrentUser()

//       if (!user) {
//         router.push("/")
//         return
//       }

//       const profile = getProfileById(user.id)

//       if (!profile || profile.role !== "admin") {
//         router.push("/")
//         return
//       }

//       setProfileData(profile)

//       // Get all profiles
//       const allProfiles = getProfiles()
//       const doctorProfiles = allProfiles.filter((p) => p.role === "doctor")

//       setDoctors(doctorProfiles)
//       setLoading(false)
//     }

//     fetchData()
//   }, [router])

//   const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     const { name, value } = e.target
//     setNewDoctorData((prev) => ({ ...prev, [name]: value }))
//   }

//   const handleSelectChange = (name: string, value: string) => {
//     setNewDoctorData((prev) => ({ ...prev, [name]: value }))
//   }

//   const generatePassword = () => {
//     const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*"
//     let password = ""
//     for (let i = 0; i < 12; i++) {
//       password += chars.charAt(Math.floor(Math.random() * chars.length))
//     }
//     return password
//   }

//   const handleCreateDoctor = () => {
//     setIsCreatingDoctor(true)

//     try {
//       // Validate inputs
//       if (
//         !newDoctorData.fullName ||
//         !newDoctorData.email ||
//         !newDoctorData.specialization ||
//         !newDoctorData.department
//       ) {
//         toast({
//           title: "Missing information",
//           description: "Please fill in all fields to create a doctor account.",
//           variant: "destructive",
//         })
//         setIsCreatingDoctor(false)
//         return
//       }

//       // Generate IDs and password
//       const doctorId = generateId("doctor-")
//       const password = generatePassword()

//       // Create user
//       const newUser = {
//         id: doctorId,
//         email: newDoctorData.email,
//         role: "doctor" as const,
//         fullName: newDoctorData.fullName,
//       }

//       // Create profile
//       const newProfile = {
//         id: doctorId,
//         fullName: newDoctorData.fullName,
//         role: "doctor" as const,
//         phone: "",
//         address: "",
//         createdAt: new Date().toISOString(),
//         updatedAt: new Date().toISOString(),
//         specialization: newDoctorData.specialization,
//         department: newDoctorData.department,
//         enableNotifications: true,
//       }

//       // Add to storage
//       addUser(newUser)
//       addProfile(newProfile)

//       // Update state
//       setDoctors((prev) => [...prev, newProfile])

//       // Set generated credentials
//       setGeneratedCredentials({
//         email: newDoctorData.email,
//         password: password,
//       })

//       // Reset form
//       setNewDoctorData({
//         fullName: "",
//         email: "",
//         specialization: "",
//         department: "",
//       })

//       // Show success message
//       toast({
//         title: "Doctor account created",
//         description: `Account for ${newDoctorData.fullName} has been created successfully.`,
//       })
//     } catch (error) {
//       console.error("Error creating doctor account:", error)
//       toast({
//         title: "Error creating account",
//         description: "There was an error creating the doctor account. Please try again.",
//         variant: "destructive",
//       })
//     } finally {
//       setIsCreatingDoctor(false)
//     }
//   }

//   const handleCopyCredentials = () => {
//     if (generatedCredentials) {
//       const text = `Email: ${generatedCredentials.email}\nPassword: ${generatedCredentials.password}`
//       navigator.clipboard.writeText(text)
//       toast({
//         title: "Credentials copied",
//         description: "The login credentials have been copied to your clipboard.",
//       })
//     }
//   }

//   const handleResetPassword = (doctorId: string, doctorName: string) => {
//     const newPassword = generatePassword()

//     // In a real app, we would update the password in the database
//     // For now, we'll just show a toast with the new password

//     toast({
//       title: "Password reset",
//       description: `New password for ${doctorName}: ${newPassword}`,
//     })
//   }

//   if (loading || !profileData) {
//     return <div className="flex items-center justify-center h-screen">Loading...</div>
//   }

//   return (
//     <DashboardLayout userRole={profileData.role} userName={profileData.fullName} userAvatar={profileData.avatarUrl}>
//       <div className="p-6">
//         <div className="mb-8">
//           <h2 className="text-3xl font-bold">Control Center</h2>
//           <p className="text-muted-foreground">Generate and manage doctor accounts in the system.</p>
//         </div>

//         <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
//           <Card className="rounded-xl">
//             <CardHeader>
//               <CardTitle>Create Doctor Account</CardTitle>
//               <CardDescription>Generate a new doctor account with login credentials.</CardDescription>
//             </CardHeader>
//             <CardContent>
//               <div className="space-y-4">
//                 <div className="space-y-2">
//                   <Label htmlFor="fullName">Full Name</Label>
//                   <Input className="rounded-xl"
//                     id="fullName"
//                     name="fullName"
//                     value={newDoctorData.fullName}
//                     onChange={handleInputChange}
//                     placeholder="Dr. Raj Mlahotra"
//                   />
//                 </div>
//                 <div className="space-y-2">
//                   <Label htmlFor="email">Email</Label>
//                   <Input className="rounded-xl"
//                     id="email"
//                     name="email"
//                     type="email"
//                     value={newDoctorData.email}
//                     onChange={handleInputChange}
//                     placeholder="doctor@example.com"
//                   />
//                 </div>
//                 <div className="space-y-2 bg-white">
//                   <Label htmlFor="specialization">Specialization</Label>
//                   <Select
//                     value={newDoctorData.specialization}
//                     onValueChange={(value) => handleSelectChange("specialization", value)}
//                   >
//                     <SelectTrigger className="bg-white rounded-xl">
//                       <SelectValue placeholder="Select specialization" />
//                     </SelectTrigger>
//                     <SelectContent className="bg-white rounded-xl">
//                       <SelectItem value="Cardiology">Cardiology</SelectItem>
//                       <SelectItem value="Neurology">Neurology</SelectItem>
//                       <SelectItem value="Orthopedics">Orthopedics</SelectItem>
//                       <SelectItem value="Pediatrics">Pediatrics</SelectItem>
//                       <SelectItem value="Dermatology">Dermatology</SelectItem>
//                       <SelectItem value="Ophthalmology">Ophthalmology</SelectItem>
//                       <SelectItem value="Gynecology">Gynecology</SelectItem>
//                       <SelectItem value="Urology">Urology</SelectItem>
//                     </SelectContent>
//                   </Select>
//                 </div>
//                 <div className="space-y-2">
//                   <Label htmlFor="department">Department</Label>
//                   <Select
//                     value={newDoctorData.department}
//                     onValueChange={(value) => handleSelectChange("department", value)}
//                   >
//                     <SelectTrigger className="bg-white rounded-xl">
//                       <SelectValue placeholder="Select department" />
//                     </SelectTrigger>
//                     <SelectContent className="bg-white rounded-xl">
//                       <SelectItem value="Cardiology Department">Cardiology Department</SelectItem>
//                       <SelectItem value="Neurology Department">Neurology Department</SelectItem>
//                       <SelectItem value="Orthopedics Department">Orthopedics Department</SelectItem>
//                       <SelectItem value="Pediatrics Department">Pediatrics Department</SelectItem>
//                       <SelectItem value="Dermatology Department">Dermatology Department</SelectItem>
//                       <SelectItem value="Ophthalmology Department">Ophthalmology Department</SelectItem>
//                       <SelectItem value="Gynecology Department">Gynecology Department</SelectItem>
//                       <SelectItem value="Urology Department">Urology Department</SelectItem>
//                     </SelectContent>
//                   </Select>
//                 </div>
//                 <Button className="w-full" onClick={handleCreateDoctor} disabled={isCreatingDoctor}>
//                   <UserPlus className="h-4 w-4 mr-2" />
//                   {isCreatingDoctor ? "Creating Account..." : "Create Doctor Account"}
//                 </Button>
//               </div>
//             </CardContent>
//           </Card>

//           {generatedCredentials && (
//             <Card className="rounded-xl">
//               <CardHeader>
//                 <CardTitle>Generated Credentials</CardTitle>
//                 <CardDescription>Login credentials for the newly created doctor account.</CardDescription>
//               </CardHeader>
//               <CardContent>
//                 <div className="space-y-4">
//                   <div className="p-4 bg-gray-50 rounded-md border">
//                     <div className="space-y-2">
//                       <div className="flex justify-between items-center">
//                         <span className="font-medium">Email:</span>
//                         <span>{generatedCredentials.email}</span>
//                       </div>
//                       <div className="flex justify-between items-center">
//                         <span className="font-medium">Password:</span>
//                         <span>{generatedCredentials.password}</span>
//                       </div>
//                     </div>
//                   </div>
//                   <div className="text-sm text-muted-foreground">
//                     Please save these credentials or share them with the doctor. For security reasons, the password will
//                     not be displayed again.
//                   </div>
//                   <Button className="w-full" variant="outline" onClick={handleCopyCredentials}>
//                     <Copy className="h-4 w-4 mr-2" />
//                     Copy Credentials
//                   </Button>
//                 </div>
//               </CardContent>
//             </Card>
//           )}
//         </div>

//         <Card className="rounded-xl">
//           <CardHeader>
//             <CardTitle>Manage Doctors</CardTitle>
//             <CardDescription>View and manage existing doctor accounts.</CardDescription>
//           </CardHeader>
//           <CardContent>
//             <Table>
//               <TableHeader>
//                 <TableRow>
//                   <TableHead>Name</TableHead>
//                   <TableHead>Specialization</TableHead>
//                   <TableHead>Department</TableHead>
//                   <TableHead>Created</TableHead>
//                   <TableHead className="text-right">Actions</TableHead>
//                 </TableRow>
//               </TableHeader>
//               <TableBody>
//                 {doctors.map((doctor) => (
//                   <TableRow key={doctor.id}>
//                     <TableCell className="font-medium">{doctor.fullName}</TableCell>
//                     <TableCell>{doctor.specialization || "Not specified"}</TableCell>
//                     <TableCell>{doctor.department || "Not specified"}</TableCell>
//                     <TableCell>{new Date(doctor.createdAt).toLocaleDateString()}</TableCell>
//                     <TableCell className="text-right">
//                       <Button variant="ghost" size="sm" onClick={() => handleResetPassword(doctor.id, doctor.fullName)}>
//                         <RefreshCw className="h-4 w-4 mr-2" />
//                         Reset Password
//                       </Button>
//                     </TableCell>
//                   </TableRow>
//                 ))}
//               </TableBody>
//             </Table>
//           </CardContent>
//         </Card>
//       </div>
//     </DashboardLayout>
//   )
// }

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

import DashboardLayout from "@/components/layout/dashboard-layout"
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"
import { UserPlus, RefreshCw, Copy, CalendarCheck2 } from "lucide-react"

import {
  getCurrentUser,
  getProfileById,
  getProfiles,
  addUser,
  addProfile,
  generateId,
} from "@/lib/browser-storage"

export default function AdminControlCenterPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [profileData, setProfileData] = useState<any>(null)
  const [doctors, setDoctors] = useState<any[]>([])
  const [newDoctorData, setNewDoctorData] = useState({
    fullName: "",
    email: "",
    specialization: "",
    department: "",
  })
  const [generatedCredentials, setGeneratedCredentials] = useState<{ email: string; password: string } | null>(null)
  const [isCreatingDoctor, setIsCreatingDoctor] = useState(false)
  const [rescheduleInitiatedBy, setRescheduleInitiatedBy] = useState("Admin")

  const appointments = [
    {
    id: "apt-1",
    patientName: "Rahul Sharma",
    doctorName: "Dr. Priya Mehta",
    dateTime: "2025-05-14 10:30 AM",
    availability: "Confirmed",
  },
  {
    id: "apt-2",
    patientName: "Anjali Verma",
    doctorName: "Dr. Arjun Khanna",
    dateTime: "2025-05-14 11:15 AM",
    availability: "Pending",
  },
  {
    id: "apt-3",
    patientName: "Raju sharma",
    doctorName: "Dr. Neha Singh",
    dateTime: "2025-05-14 12:00 PM",
    availability: "Rescheduled",
  },
  {
    id: "apt-4",
    patientName: "Sneha Iyer",
    doctorName: "Dr. Rajiv Menon",
    dateTime: "2025-05-14 01:45 PM",
    availability: "Confirmed",
  },
  ]

  useEffect(() => {
    const fetchData = () => {
      const user = getCurrentUser()
      if (!user) return router.push("/")

      const profile = getProfileById(user.id)
      if (!profile || profile.role !== "admin") return router.push("/")

      setProfileData(profile)
      const allProfiles = getProfiles()
      const doctorProfiles = allProfiles.filter((p) => p.role === "doctor")
      setDoctors(doctorProfiles)
      setLoading(false)
    }

    fetchData()
  }, [router])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewDoctorData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setNewDoctorData((prev) => ({ ...prev, [name]: value }))
  }

  const generatePassword = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*"
    return Array.from({ length: 12 }, () => chars[Math.floor(Math.random() * chars.length)]).join("")
  }

  const handleCreateDoctor = () => {
    setIsCreatingDoctor(true)
    try {
      const { fullName, email, specialization, department } = newDoctorData
      if (!fullName || !email || !specialization || !department) {
        toast({ title: "Missing information", description: "Please fill in all fields.", variant: "destructive" })
        setIsCreatingDoctor(false)
        return
      }

      const doctorId = generateId("doctor-")
      const password = generatePassword()

      const newUser = { id: doctorId, email, role: "doctor" as const, fullName }
      const newProfile = {
        id: doctorId,
        fullName,
        role: "doctor" as const,
        phone: "",
        address: "",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        specialization,
        department,
        enableNotifications: true,
      }

      addUser(newUser)
      addProfile(newProfile)
      setDoctors((prev) => [...prev, newProfile])
      setGeneratedCredentials({ email, password })

      setNewDoctorData({ fullName: "", email: "", specialization: "", department: "" })

      toast({ title: "Doctor created", description: `Account for ${fullName} created.` })
    } catch {
      toast({ title: "Error", description: "Failed to create doctor.", variant: "destructive" })
    } finally {
      setIsCreatingDoctor(false)
    }
  }

  const handleCopyCredentials = () => {
    if (generatedCredentials) {
      const text = `Email: ${generatedCredentials.email}\nPassword: ${generatedCredentials.password}`
      navigator.clipboard.writeText(text)
      toast({ title: "Copied", description: "Credentials copied to clipboard." })
    }
  }

  const handleResetPassword = (doctorId: string, doctorName: string) => {
    const newPassword = generatePassword()
    toast({
      title: "Password Reset",
      description: `New password for ${doctorName}: ${newPassword}`,
    })
  }

  const handleDeleteDoctor = (doctorId: string) => {
    if (!confirm("Are you sure?")) return
    const updatedDoctors = doctors.filter((doc) => doc.id !== doctorId)
    const allProfiles = getProfiles().filter((p) => p.id !== doctorId)
    localStorage.setItem("profiles", JSON.stringify(allProfiles))
    setDoctors(updatedDoctors)
    toast({ title: "Doctor Deleted", description: "Doctor removed successfully." })
  }

  if (loading || !profileData) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  return (
    <DashboardLayout userRole={profileData.role} userName={profileData.fullName} userAvatar={profileData.avatarUrl}>
      <div className="p-6 space-y-8">

        {/* Header */}
        <div>
          <h2 className="text-3xl font-bold">Control Center</h2>
          <p className="text-muted-foreground">Generate and manage doctor accounts in the system.</p>
        </div>

        {/* Create Doctor */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="rounded-xl">
            <CardHeader>
              <CardTitle>Create Doctor Account</CardTitle>
              <CardDescription>Generate a new doctor account with login credentials.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="fullName">Full Name</Label>
                <Input id="fullName" name="fullName" value={newDoctorData.fullName} onChange={handleInputChange} placeholder="Dr. Raj Malhotra" className="rounded-xl" />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" name="email" type="email" value={newDoctorData.email} onChange={handleInputChange} placeholder="doctor@example.com" className="rounded-xl" />
              </div>
              <div>
                <Label htmlFor="specialization">Specialization</Label>
                <Select value={newDoctorData.specialization} onValueChange={(val) => handleSelectChange("specialization", val)}>
                  <SelectTrigger className="rounded-xl bg-white"><SelectValue placeholder="Select specialization" /></SelectTrigger>
                  <SelectContent className="bg-white rounded-xl">
                    {["Cardiology", "Neurology", "Orthopedics", "Pediatrics", "Dermatology"].map((item) => (
                      <SelectItem key={item} value={item}>{item}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="department">Department</Label>
                <Select value={newDoctorData.department} onValueChange={(val) => handleSelectChange("department", val)}>
                  <SelectTrigger className="rounded-xl bg-white"><SelectValue placeholder="Select department" /></SelectTrigger>
                  <SelectContent className="bg-white rounded-xl">
                    {["Cardiology", "Neurology", "Orthopedics", "Pediatrics", "Dermatology"].map((dept) => (
                      <SelectItem key={dept} value={`${dept} Department`}>{dept} Department</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button className="w-full" onClick={handleCreateDoctor} disabled={isCreatingDoctor}>
                <UserPlus className="mr-2 h-4 w-4" />
                {isCreatingDoctor ? "Creating..." : "Create Doctor Account"}
              </Button>
            </CardContent>
          </Card>

          {generatedCredentials && (
            <Card className="rounded-xl">
              <CardHeader>
                <CardTitle>Generated Credentials</CardTitle>
                <CardDescription>Credentials for new doctor login.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-gray-50 border rounded-md space-y-2">
                  <div className="flex justify-between"><strong>Email:</strong> {generatedCredentials.email}</div>
                  <div className="flex justify-between"><strong>Password:</strong> {generatedCredentials.password}</div>
                </div>
                <Button variant="outline" className="w-full" onClick={handleCopyCredentials}>
                  <Copy className="mr-2 h-4 w-4" /> Copy Credentials
                </Button>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Manage Doctors Table */}
        <Card className="rounded-xl shadow-md">
          <CardHeader>
            <CardTitle>Manage Doctors</CardTitle>
            <CardDescription>View, reset, or delete doctor accounts.</CardDescription>
          </CardHeader>
          <CardContent className="overflow-x-auto">
            <Table className="rounded-xl border border-blue-100">
              <TableHeader>
                <TableRow className="bg-gradient-to-r from-blue-100 to-green-100 text-blue-900">
                  <TableHead>Name</TableHead>
                  <TableHead>Specialization</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {doctors.length > 0 ? doctors.map((doctor) => (
                  <TableRow key={doctor.id} className="hover:bg-blue-50 transition">
                    <TableCell className="font-medium text-blue-900">{doctor.fullName}</TableCell>
                    <TableCell>{doctor.specialization}</TableCell>
                    <TableCell>{doctor.department}</TableCell>
                    <TableCell>{new Date(doctor.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button size="sm" variant="ghost" onClick={() => handleResetPassword(doctor.id, doctor.fullName)}>
                        <RefreshCw className="h-4 w-4 mr-1" /> Reset
                      </Button>
                      <Button size="sm" variant="ghost" className="text-red-600" onClick={() => handleDeleteDoctor(doctor.id)}>
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow><TableCell colSpan={5} className="text-center text-gray-500 py-4">No doctors found.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Manage Appointments */}
        <Card className="rounded-xl shadow-md">
          <CardHeader>
            <CardTitle>Manage Appointments</CardTitle>
            <CardDescription>Monitor and reschedule patient appointments.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
              <Label className="text-sm text-muted-foreground">Rescheduling Initiated By: </Label>
              <Select value={rescheduleInitiatedBy} onValueChange={setRescheduleInitiatedBy}>
                <SelectTrigger className="w-[200px] rounded-xl bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Table className="rounded-xl border border-blue-100">
              <TableHeader>
                <TableRow className="bg-gradient-to-r from-green-100 to-blue-100 text-blue-900">
                  <TableHead>Patient</TableHead>
                  <TableHead>Doctor</TableHead>
                  <TableHead>Date/Time</TableHead>
                  <TableHead>Reschedule</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {appointments.map((apt) => (
                  <TableRow key={apt.id} className="hover:bg-green-50 transition">
                    <TableCell>{apt.patientName}</TableCell>
                    <TableCell>{apt.doctorName}</TableCell>
                    <TableCell>{apt.dateTime}</TableCell>
                     <TableCell className="text-left">
                           <Button size="sm" onClick={() => toast({ title: "Reschedule", description: `Rescheduled by ${rescheduleInitiatedBy}.` })}>
                               <CalendarCheck2 className="mr-1 h-4 w-4" /> Reschedule
                          </Button>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 text-sm rounded-full ${
                        apt.availability === "Confirmed" ? "bg-green-100 text-green-700" :
                        apt.availability === "Pending" ? "bg-yellow-100 text-yellow-700" :
                        "bg-blue-100 text-blue-700"
                      }`}>
                        {apt.availability}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

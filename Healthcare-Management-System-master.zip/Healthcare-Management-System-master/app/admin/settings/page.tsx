"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import DashboardLayout from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { Bell, Shield, Save, Trash, UserMinus, Star } from "lucide-react"
import { getCurrentUser, getProfileById, updateProfile, deleteAccount } from "@/lib/browser-storage"

export default function AdminSettingsPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [profileData, setProfileData] = useState<any>(null)
  const [settings, setSettings] = useState({
    enableNotifications: true,
    enableTwoFactor: false,
    darkMode: false,
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [feedback, setFeedback] = useState<any[]>([]) // Feedback state

  useEffect(() => {
    const fetchData = async () => {
      const user = getCurrentUser()

      if (!user) {
        router.push("/")
        return
      }

      const profile = getProfileById(user.id)

      if (!profile || profile.role !== "admin") {
        router.push("/")
        return
      }

      setProfileData(profile)
      setSettings({
        enableNotifications: profile.enableNotifications !== false,
        enableTwoFactor: profile.enableTwoFactor || false,
        darkMode: profile.darkMode || false,
      })

      // Simulating feedback data fetch (in real app this would be dynamic)
      setFeedback([
        { id: 1, user: "User1", rating: 4, comments: "Great platform!" },
        { id: 2, user: "User2", rating: 5, comments: "Excellent user experience!" },
      ])

      setLoading(false)
    }

    fetchData()
  }, [router])

  const handleToggleChange = (name: string, checked: boolean) => {
    setSettings((prev) => ({ ...prev, [name]: checked }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Update profile
      const updatedProfile = {
        ...profileData,
        enableNotifications: settings.enableNotifications,
        enableTwoFactor: settings.enableTwoFactor,
        darkMode: settings.darkMode,
        updatedAt: new Date().toISOString(),
      }

      // Update in storage
      updateProfile(updatedProfile)

      // Update state
      setProfileData(updatedProfile)

      // Show success message
      toast({
        title: "Settings updated",
        description: "Your settings have been updated successfully.",
      })
    } catch (error) {
      console.error("Error updating settings:", error)
      toast({
        title: "Error updating settings",
        description: "There was an error updating your settings. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteAccount = async () => {
    const confirmation = window.confirm("Are you sure you want to delete this account? This action is irreversible.")
    if (confirmation) {
      try {
        deleteAccount(profileData.id)
        toast({
          title: "Account deleted",
          description: "Your account has been deleted successfully.",
        })
        router.push("/") // Redirect to homepage or login page
      } catch (error) {
        toast({
          title: "Error deleting account",
          description: "There was an error deleting the account. Please try again.",
          variant: "destructive",
        })
      }
    }
  }

  const handleDisableAccount = () => {
    const confirmation = window.confirm("Are you sure you want to disable this account? The user will not be able to log in.")
    if (confirmation) {
      const updatedProfile = { ...profileData, isDisabled: true }
      updateProfile(updatedProfile)
      setProfileData(updatedProfile)

      toast({
        title: "Account disabled",
        description: "The account has been disabled successfully.",
      })
    }
  }

  const handleEnableAccount = () => {
    const updatedProfile = { ...profileData, isDisabled: false }
    updateProfile(updatedProfile)
    setProfileData(updatedProfile)

    toast({
      title: "Account enabled",
      description: "The account has been enabled successfully.",
    })
  }

  if (loading || !profileData) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  return (
    <DashboardLayout userRole={profileData.role} userName={profileData.fullName} userAvatar={profileData.avatarUrl}>
      <div className="p-6">
        <h1 className="text-3xl font-bold mb-8">Admin Settings</h1>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
                <CardDescription>Manage your notification preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="enableNotifications" className="flex items-center">
                      <Bell className="h-4 w-4 mr-2" />
                      Enable Notifications
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Receive notifications about system updates and activities
                    </p>
                  </div>
                  <Switch
                    id="enableNotifications"
                    checked={settings.enableNotifications}
                    onCheckedChange={(checked) => handleToggleChange("enableNotifications", checked)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Security</CardTitle>
                <CardDescription>Manage your security settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="enableTwoFactor" className="flex items-center">
                      <Shield className="h-4 w-4 mr-2" />
                      Two-Factor Authentication
                    </Label>
                    <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
                  </div>
                  <Switch
                    id="enableTwoFactor"
                    checked={settings.enableTwoFactor}
                    onCheckedChange={(checked) => handleToggleChange("enableTwoFactor", checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-end mt-6">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                "Saving..."
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Settings
                </>
              )}
            </Button>
          </div>
        </form>

        {/* Account Management */}
        <div className="mt-8 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Account Management</CardTitle>
              <CardDescription>Manage account settings and status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Button 
                  variant="destructive" 
                  onClick={handleDeleteAccount} 
                  className="bg-red-500 text-white hover:bg-red-600 focus:ring-2 focus:ring-red-300"
                >
                  <Trash className="mr-2 h-4 w-4" />
                  Delete Account
                </Button>
              </div>
              <div className="flex items-center justify-between">
                <Button
                  variant={profileData.isDisabled ? "default" : "destructive"}
                  onClick={profileData.isDisabled ? handleEnableAccount : handleDisableAccount}
                >
                  {profileData.isDisabled ? (
                    <>
                      <UserMinus className="mr-2 h-4 w-4" />
                      Enable Account
                    </>
                  ) : (
                    <>
                      <UserMinus className="mr-2 h-4 w-4" />
                      Disable Account
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Feedback & Rating */}
          <Card>
            <CardHeader>
              <CardTitle>Feedback & Rating</CardTitle>
              <CardDescription>View user feedback and ratings</CardDescription>
            </CardHeader>
            <CardContent>
              {feedback.length === 0 ? (
                <p>No feedback available.</p>
              ) : (
                <ul>
                  {feedback.map((item) => (
                    <li key={item.id} className="mb-4">
                      <div className="flex justify-between">
                        <span className="font-semibold">{item.user}</span>
                        <span>{item.rating} <Star className="inline h-4 w-4 text-yellow-500" /></span>
                      </div>
                      <p>{item.comments}</p>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}

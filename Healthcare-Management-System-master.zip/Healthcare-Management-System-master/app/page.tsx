"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { initializeDummyData, setCurrentUser } from "@/lib/browser-storage"
import { HomeIcon, SparklesIcon, LockClosedIcon, PhoneIcon } from '@heroicons/react/24/outline';
import '../styles/globals.css';  // Make sure this path is correct

export default function Home() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [rememberMe, setRememberMe] = useState(false)

  useEffect(() => {
    // Initialize dummy data when the app loads
    initializeDummyData()
  }, [])

  const handleDoctorLogin = () => {
    setCurrentUser({
      id: "doctor-1",
      email: "john.smith@example.com",
      role: "doctor",
      fullName: "Dr. John Smith",
    })
    router.push("/dashboard")
  }

  const handlePatientLogin = () => {
    setCurrentUser({
      id: "patient-1",
      email: "michael.brown@example.com",
      role: "patient",
      fullName: "Michael Brown",
    })
    router.push("/dashboard")
  }

  const handleAdminLogin = () => {
    setCurrentUser({
      id: "admin-1",
      email: "admin@example.com",
      role: "admin",
      fullName: "System Administrator",
    })
    router.push("/admin/dashboard")
  }

  const handleSignIn = (e) => {
    e.preventDefault()
    // Handle form submission - for now just use doctor login as default
    handleDoctorLogin()
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
<header className="bg-white/30 backdrop-blur-md border-b border-white/20 sticky top-0 z-10 shadow-sm">
<div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center">
            
          <img
          src="https://media-hosting.imagekit.io/0490645fd3ab43bd/3fd7d62d51f0ce46112f4d7eb562fa93-removebg-preview.png?Expires=1841750877&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=iqgCx1IBub0VdxHfANwV3YzEnrMe5Zmji1eAdsCNI5WTFBTfCe6zg5pdtpDr7vQuThxC8uImLEVG~Ga31JxrAVrOwjTBkE9thwN0SBS12xUbRc~QamBDfrV-2XgDVG7JytYoNzdmEnuCPlJ~IlTwaGtoqquvwBuj-Ig3zQiG~0Ck3nagOnWQryKlwrwITBLY04G3zVk5EpOPGg4Pnusp47lutmIYSse7d-3nRC9zlJQueTvkeYssAkAm9jOzA0skaWlUSnHapK~A-8ImA8gl4GwdhEiNyEb24juVCYjRZJQodDQmTRc0SeE8QLtETC86~LdXWatH1QgcXuAPDrhGdA__"
          alt="Health Care Logo"
          className="h-12 mx-auto mb-2"
        />
            <h1 className="text-xl font-bold text-primary ml-2">Healthcare Management System</h1>
          </div>
          <nav>
            <ul className="flex space-x-6">
            <li>
  <Link href="/" className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors">
    <HomeIcon className="h-5 w-5" />
    Home
  </Link>
</li>
<li>
  <Link href="#features" className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors">
    <SparklesIcon className="h-5 w-5" />
    Features
  </Link>
</li>
<li>
  <Link href="#login" className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors">
    <LockClosedIcon className="h-5 w-5" />
    Login
  </Link>
</li>
<li>
  <Link href="#contact" className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors">
    <PhoneIcon className="h-5 w-5" />
    Contact Us
  </Link>
</li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero section with gradient background */}
        <div className="abstract-fluid-bg text-white">
        <div className="container mx-auto px-4 py-16">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h2 className="text-4xl font-bold tracking-tight text-blue-800">Secure and Efficient Hospital Management</h2>
                <p className="text-lg text-blue-700 opacity-90">
                  Our advanced healthcare management system integrates patient records, appointments, and secure medical
                  data storage into one seamless platform. With SSL encryption, two-factor authentication, and cloud
                  security, your healthcare organization can operate securely and efficiently.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Button size="lg" className="bg-blue-100 rounded-xl text-blue-700 hover:bg-blue-50" asChild>
                    <a href="#login">Get Started</a>
                  </Button>
                  <Button size="lg" variant="outline" className="border-white text-black hover:bg-white hover:text-blue-700">
                    Learn More
                  </Button>
                </div>
              </div>
              <div className="flex justify-center">
                <div className="relative">
                  <div className="absolute inset-0 bg-white rounded-full opacity-20 blur-3xl"></div>
                  <img
                    src="https://media-hosting.imagekit.io/d0f7769a58714079/erasebg-transformed.webp?Expires=1841223174&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=1nlfgJkd4srF5YOtpLu5SMwA5e4Vdxr~BVfPrydFUOyxG63M76AOv0wic60Ie~NcIweXmPYvoitNg6r7CPsDxdcKVUI56Go72CDSqTp5~2GBsxmQvowIimlST7ko63jQGm4t0N47GStCBxzk6xyfCmn2KbUYh5DS7TQQuJ5szX0LeOZuapoHo6Y~OB1672qp16b0Zc1B1zo~jL4tvRtyi7ox~l2r~4OJ0SOSDT-pTsR1l3h-0-ZQm9q8siGb7ccHqbTPDg9UnFQKputjDn9JoslKpNm0hOrdA~HRH1wH5rIfiJZ8SV55IE9N78ycqqqfTZXZIZcfhVLzZ3LcZA9vJQ__"
                    alt="Healthcare Management"
                    className="relative rounded-xl "
                    width={600}
                    height={600}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features section */}
        <section id="features" className="py-24 bg-white mb-10">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl font-bold mb-4">Key Features</h2>
              <p className="text-lg text-slate-600">Discover how our platform simplifies healthcare management while ensuring security and efficiency</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="border-none shadow-lg rounded-xl hover:shadow-xl transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-blue-600"
                    >
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                      <path d="M14 2v6h6"></path>
                      <path d="M16 13H8"></path>
                      <path d="M16 17H8"></path>
                      <path d="M10 9H8"></path>
                    </svg>
                  </div>
                  <CardTitle className="text-xl font-semibold">Digital Records</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    No more messy paperwork! Store and manage all patient medical records in one secure place. Patients get
                    easy access to their reports, reducing unnecessary hospital visits.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="border-none shadow-lg rounded-xl hover:shadow-xl transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-green-600"
                    >
                      <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                      <line x1="16" y1="2" x2="16" y2="6"></line>
                      <line x1="8" y1="2" x2="8" y2="6"></line>
                      <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                  </div>
                  <CardTitle className="text-xl font-semibold">Appointment Scheduling</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Streamline the appointment booking process for both doctors and patients. Reduce no-shows with automated
                    reminders and allow patients to reschedule with ease.
                  </p>
                </CardContent>
              </Card>
              
              <Card className="border-none shadow-lg rounded-xl hover:shadow-xl transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-purple-600"
                    >
                      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                      <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                  </div>
                  <CardTitle className="text-xl font-semibold">Medical Staff Portal</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    A dedicated space for doctors to manage their workflow efficiently. View upcoming appointments, patient
                    histories, update prescriptions, and track patient progress.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Login section */}
        <section id="login" className="py-20 bg-gradient-to-b from-slate-50 to-slate-100">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-16">Access Your Account</h2>
            <div className="max-w-md mx-auto">
              <Card className="border-none shadow-2xl rounded-xl overflow-hidden">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-700 h-3"></div>
                <CardHeader className="pb-4 pt-6">
                  <CardTitle className="text-2xl font-bold text-center">Sign in to your account</CardTitle>
                  <CardDescription className="text-center">
                    Or <Link href="#" className="text-blue-600 hover:text-blue-800 font-medium">create a new account</Link>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSignIn} className="space-y-4">
                    <div className="space-y-2">
                      <label htmlFor="email" className="block text-sm font-medium text-slate-700">
                        Email address
                      </label>
                      <input
                        id="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                        placeholder="you@example.com"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center rounded-xl">
                        <label htmlFor="password" className="block text-sm font-medium rounded-xl text-slate-700">
                          Password
                        </label>
                        <Link href="#" className="text-sm text-blue-600 hover:text-blue-800">
                          Forgot password?
                        </Link>
                      </div>
                      <input
                        id="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                        placeholder="••••••••"
                      />
                    </div>
                    
                    <div className="flex items-center">
                      <input
                        id="remember-me"
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="h-4 w-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                      />
                      <label htmlFor="remember-me" className="ml-2 block text-sm text-slate-700">
                        Remember me
                      </label>
                    </div>
                    
                    <button
                      type="submit"
                      className="w-full bg-blue-600 rounded-xl hover:bg-blue-700 text-white font-medium py-3 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                    >
                      Sign in
                    </button>
                  </form>
                  
                  <div className="mt-8 pt-6 border-t border-slate-200">
                    <p className="text-center text-sm text-slate-600 mb-4">Demo accounts:</p>
                    <div className="flex justify-center space-x-6">
                      <button
                        onClick={handleAdminLogin}
                        className="flex items-center text-blue-600 hover:text-blue-800 text-sm font-medium transition-colors"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="mr-1"
                        >
                          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                        </svg>
                        Admin
                      </button>
                      <button
                        onClick={handleDoctorLogin}
                        className="flex items-center text-blue-600 hover:text-blue-800 text-sm font-medium transition-colors"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="mr-1"
                        >
                          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                          <polyline points="9 22 9 12 15 12 15 22"></polyline>
                        </svg>
                        Doctor
                      </button>
                      <button
                        onClick={handlePatientLogin}
                        className="flex items-center text-blue-600 hover:text-blue-800 text-sm font-medium transition-colors"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="mr-1"
                        >
                          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                          <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                        Patient
                      </button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Contact section */}
        <section id="contact" className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-6">Get In Touch</h2>
              <p className="text-lg text-slate-600 mb-10">
                Have questions about our healthcare management system? Our team is here to help you get started.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button size="lg" variant="outline" className="px-8 py-6 rounded-xl text-base">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mr-2"
                  >
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                  </svg>
                  Contact Us
                </Button>
                <Button size="lg" className="px-8 py-6 rounded-xl text-base bg-blue-600 hover:bg-blue-700">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mr-2"
                  >
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                    <line x1="8" y1="21" x2="16" y2="21"></line>
                    <line x1="12" y1="17" x2="12" y2="21"></line>
                  </svg>
                  Request Demo
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div>
              <div className="flex items-center mb-4">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-6 h-6 mr-2 text-blue-400"
                >
                  <path d="M19.5 9c0 3.5-2.5 6.5-6 8.5-3.5-2-6-5-6-8.5a6 6 0 0 1 12 0Z" />
                  <circle cx="13.5" cy="9" r="1.5" />
                </svg>
                <h3 className="text-lg font-semibold">Healthcare Management System</h3>
              </div>
              <p className="text-sm text-slate-300">Secure healthcare management for doctors and patients.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Important Links</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="#" className="text-sm text-slate-300 hover:text-white transition-colors flex items-center">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="14" 
                      height="14" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className="mr-2"
                    >
                      <polyline points="9 18 15 12 9 6"></polyline>
                    </svg>
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-slate-300 hover:text-white transition-colors flex items-center">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="14" 
                      height="14" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className="mr-2"
                    >
                      <polyline points="9 18 15 12 9 6"></polyline>
                    </svg>
                    Departments
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-sm text-slate-300 hover:text-white transition-colors flex items-center">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="14" 
                      height="14" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className="mr-2"
                    >
                      <polyline points="9 18 15 12 9 6"></polyline>
                    </svg>
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Contact</h3>
              <address className="not-italic text-sm text-slate-300">
                <div className="flex items-start mb-2">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="16" 
                    height="16" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="mr-2 mt-1 text-blue-400"
                  >
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                    <circle cx="12" cy="10" r="3"></circle>
                  </svg>
                  <span>123 Health Street, City, Country</span>
                </div>
                <div className="flex items-center mb-2">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="16" 
                    height="16" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="mr-2 text-blue-400"
                  >
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                    <polyline points="22,6 12,13 2,6"></polyline>
                  </svg>
                  <span>contact@hms.com</span>
                </div>
                <div className="flex items-center">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="16" 
                    height="16" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="mr-2 text-blue-400"
                  >
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                  </svg>
                  <span>+91 1234567890</span>
                </div>
              </address>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-slate-800 text-center">
            <p className="text-sm text-slate-400">
              &copy; {new Date().getFullYear()} Healthcare Management System. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
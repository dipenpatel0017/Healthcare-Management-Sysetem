// "use client"

// import { useEffect, useState } from "react"
// import { useRouter } from "next/navigation"
// import DashboardLayout from "@/components/layout/dashboard-layout"
// import {
//   Card,
//   CardContent,
//   CardDescription,
//   CardHeader,
//   CardTitle,
// } from "@/components/ui/card"
// import { Button } from "@/components/ui/button"
// import { Badge } from "@/components/ui/badge"
// import {
//   Table,
//   TableBody,
//   TableCell,
//   TableHead,
//   TableHeader,
//   TableRow,
// } from "@/components/ui/table"
// import { CreditCard, Download, Eye } from "lucide-react"
// import { Dialog, DialogContent } from "@/components/ui/dialog"
// import { getCurrentUser, getProfileById, getProfiles } from "@/lib/browser-storage"
// import { generatePDF } from "@/lib/pdf-generator"

// const getInvoicesByPatientId = (patientId: string) => [
//   {
//     id: "1",
//     invoiceNumber: "INV-001",
//     createdAt: "2024-05-01",
//     dueDate: "2024-05-10",
//     status: "paid",
//     doctorId: "doc123",
//     amount: 2000,
//     taxRate: 18,
//     taxAmount: 360,
//     totalAmount: 2360,
//     items: [
//       { id: "i1", description: "Consultation", amount: 1000 },
//       { id: "i2", description: "X-Ray", amount: 1000 },
//     ],
//   },
//   {
//     id: "2",
//     invoiceNumber: "INV-002",
//     createdAt: "2024-04-15",
//     dueDate: "2024-04-22",
//     status: "unpaid",
//     doctorId: "doc456",
//     amount: 1500,
//     taxRate: 12,
//     taxAmount: 180,
//     totalAmount: 1680,
//     items: [
//       { id: "i1", description: "Blood Test", amount: 500 },
//       { id: "i2", description: "Ultrasound", amount: 1000 },
//     ],
//   },
//   {
//     id: "3",
//     invoiceNumber: "INV-003",
//     createdAt: "2024-03-10",
//     dueDate: "2024-03-17",
//     status: "overdue",
//     doctorId: "doc789",
//     amount: 800,
//     taxRate: 5,
//     taxAmount: 40,
//     totalAmount: 840,
//     items: [
//       { id: "i1", description: "General Checkup", amount: 800 },
//     ],
//   },
//   {
//     id: "4",
//     invoiceNumber: "INV-004",
//     createdAt: "2024-02-20",
//     dueDate: "2024-02-27",
//     status: "paid",
//     doctorId: "doc123",
//     amount: 2200,
//     taxRate: 18,
//     taxAmount: 396,
//     totalAmount: 2596,
//     items: [
//       { id: "i1", description: "MRI Scan", amount: 2000 },
//       { id: "i2", description: "Report Charges", amount: 200 },
//     ],
//   },
//   {
//     id: "5",
//     invoiceNumber: "INV-005",
//     createdAt: "2024-01-05",
//     dueDate: "2024-01-12",
//     status: "paid",
//     doctorId: "doc456",
//     amount: 1000,
//     taxRate: 10,
//     taxAmount: 100,
//     totalAmount: 1100,
//     items: [
//       { id: "i1", description: "ECG", amount: 500 },
//       { id: "i2", description: "Consultation", amount: 500 },
//     ],
//   },
// ]

// export default function InvoicesPage() {
//   const router = useRouter()
//   const [loading, setLoading] = useState(true)
//   const [profileData, setProfileData] = useState<any>(null)
//   const [invoices, setInvoices] = useState<any[]>([])
//   const [selectedInvoice, setSelectedInvoice] = useState<any>(null)
//   const [isViewOpen, setIsViewOpen] = useState(false)

//   useEffect(() => {
//     const user = getCurrentUser()
//     if (!user) return router.push("/")

//     const profile = getProfileById(user.id)
//     if (!profile) return router.push("/")
//     if (profile.role !== "patient") return router.push("/dashboard")

//     setProfileData(profile)
//     const raw = getInvoicesByPatientId(user.id)
//     const enriched = raw.map(inv => {
//       const doc = getProfiles().find(p => p.id === inv.doctorId)
//       return { ...inv, doctorName: doc?.fullName || "Unknown Doctor" }
//     })
//     setInvoices(enriched)
//     setLoading(false)
//   }, [router])

//   const formatDate = (d: string) =>
//     new Date(d).toLocaleDateString(undefined, {
//       year: "numeric",
//       month: "long",
//       day: "numeric",
//     })

//   const formatCurrency = (amt: number) =>
//     new Intl.NumberFormat("en-IN", {
//       style: "currency",
//       currency: "INR",
//     }).format(amt)

//   const statusClasses: Record<string, string> = {
//     paid: "bg-green-100 text-green-800",
//     unpaid: "bg-yellow-100 text-yellow-800",
//     overdue: "bg-red-100 text-red-800",
//   }

//   const handleView = (inv: any) => {
//     setSelectedInvoice(inv)
//     setIsViewOpen(true)
//   }

//   const handleDownload = (inv: any) => {
//     const items = inv.items.map((i: any) => `${i.description}: ${formatCurrency(i.amount)}`).join("\n")
//     const content = `# Invoice ${inv.invoiceNumber}

// **Date:** ${formatDate(inv.createdAt)}  
// **Due:** ${formatDate(inv.dueDate)}  
// **Status:** ${inv.status.toUpperCase()}  
// **Doctor:** ${inv.doctorName}

// ### Items
// ${items}

// **Subtotal:** ${formatCurrency(inv.amount)}  
// **Tax (${inv.taxRate}%):** ${formatCurrency(inv.taxAmount)}  
// **Total:** ${formatCurrency(inv.totalAmount)}`
//     generatePDF(content, `invoice-${inv.invoiceNumber}.pdf`)
//   }

//   if (loading || !profileData) {
//     return <div className="flex items-center justify-center h-screen">Loading…</div>
//   }

//   return (
//     <DashboardLayout
//       userRole={profileData.role}
//       userName={profileData.fullName}
//       userAvatar={profileData.avatarUrl}
//     >
//       <div className="p-6">
//         <h1 className="text-3xl font-bold text-black mb-6">My Invoices</h1>

//         <Card className="rounded-xl">
//           <CardHeader>
//             <CardTitle className="flex items-center text-sky-600">
//               <CreditCard className="mr-2 h-5 w-5 text-sky-500" /> Billing History
//             </CardTitle>
//             <CardDescription>View and manage your invoices</CardDescription>
//           </CardHeader>
//           <CardContent>
//             {invoices.length > 0 ? (
//               <div className="overflow-x-auto">
//                 <Table>
//                   <TableHeader className="bg-sky-50">
//                     <TableRow>
//                       {["Invoice #", "Doctor", "Date", "Amount", "Status", "Actions"].map((h, idx) => (
//                         <TableHead
//                           key={h}
//                           className={idx === 5 ? "text-right whitespace-nowrap" : "whitespace-nowrap"}
//                         >
//                           {h}
//                         </TableHead>
//                       ))}
//                     </TableRow>
//                   </TableHeader>
//                   <TableBody>
//                     {invoices.map(inv => (
//                       <TableRow key={inv.id}>
//                         <TableCell>{inv.invoiceNumber}</TableCell>
//                         <TableCell>{inv.doctorName}</TableCell>
//                         <TableCell>{formatDate(inv.createdAt)}</TableCell>
//                         <TableCell>{formatCurrency(inv.totalAmount)}</TableCell>
//                         <TableCell>
//                           <Badge className={statusClasses[inv.status]}>
//                             {inv.status.toUpperCase()}
//                           </Badge>
//                         </TableCell>
//                         <TableCell className="text-right">
//                           <div className="inline-flex gap-2">
//                             <Button className="bg-sky-500 hover:bg-sky-600 text-white text-sm" onClick={() => handleView(inv)}>
//                               <Eye className="mr-1 h-4 w-4" /> View
//                             </Button>
//                             <Button className="bg-green-600 hover:bg-green-700 text-white text-sm" onClick={() => handleDownload(inv)}>
//                               <Download className="mr-1 h-4 w-4" /> Download
//                             </Button>
//                           </div>
//                         </TableCell>
//                       </TableRow>
//                     ))}
//                   </TableBody>
//                 </Table>
//               </div>
//             ) : (
//               <div className="flex flex-col items-center justify-center p-12 text-center text-gray-500">
//                 <CreditCard className="mb-4 h-8 w-8 text-sky-300" />
//                 <h3 className="text-lg font-medium">No Invoices Found</h3>
//                 <p>You don’t have any invoices yet.</p>
//               </div>
//             )}
//           </CardContent>
//         </Card>

//         <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
//           <DialogContent className="max-w-2xl bg-white rounded-xl shadow-lg border p-6">
//             <div className="text-center mb-4">
//               <img
//                 src="https://i.pinimg.com/originals/3f/d7/d6/3fd7d62d51f0ce46112f4d7eb562fa93.png"
//                 alt="Health Care Logo"
//                 className="h-12 mx-auto mb-2"
//               />
//               <h2 className="text-2xl font-bold text-sky-700">Health Care</h2>
//               <p className="text-sm text-gray-500">Invoice Summary</p>
//               <hr className="my-4 border-sky-200" />
//             </div>

//             <div className="grid grid-cols-2 text-sm mb-6 gap-4">
//               <div>
//                 <p className="text-muted-foreground font-medium">Invoice No:</p>
//                 <p>{selectedInvoice?.invoiceNumber}</p>
//                 <p className="text-muted-foreground font-medium mt-2">Doctor:</p>
//                 <p>{selectedInvoice?.doctorName}</p>
//               </div>
//               <div className="text-right">
//                 <p className="text-muted-foreground font-medium">Date:</p>
//                 <p>{formatDate(selectedInvoice?.createdAt)}</p>
//                 <p className="text-muted-foreground font-medium mt-2">Due Date:</p>
//                 <p>{formatDate(selectedInvoice?.dueDate)}</p>
//               </div>
//             </div>

//             <div className="overflow-x-auto mb-6">
//               <table className="w-full border border-sky-200 text-sm">
//                 <thead className="bg-sky-100 text-sky-700">
//                   <tr>
//                     <th className="p-2 border border-sky-200 text-left">Item</th>
//                     <th className="p-2 border border-sky-200 text-right">Amount</th>
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {selectedInvoice?.items?.map((item: any) => (
//                     <tr key={item.id} className="hover:bg-green-50">
//                       <td className="p-2 border border-sky-200">{item.description}</td>
//                       <td className="p-2 border border-sky-200 text-right">
//                         {formatCurrency(item.amount)}
//                       </td>
//                     </tr>
//                   ))}
//                 </tbody>
//                 <tfoot className="bg-green-100 text-green-700">
//                   <tr>
//                     <td className="p-2 border border-sky-200 font-semibold">Subtotal</td>
//                     <td className="p-2 border border-sky-200 text-right">{formatCurrency(selectedInvoice?.amount)}</td>
//                   </tr>
//                   <tr>
//                     <td className="p-2 border border-sky-200 font-semibold">Tax ({selectedInvoice?.taxRate}%)</td>
//                     <td className="p-2 border border-sky-200 text-right">{formatCurrency(selectedInvoice?.taxAmount)}</td>
//                   </tr>
//                   <tr>
//                     <td className="p-2 border border-sky-200 font-bold">Total</td>
//                     <td className="p-2 border border-sky-200 text-right font-bold">{formatCurrency(selectedInvoice?.totalAmount)}</td>
//                   </tr>
//                 </tfoot>
//               </table>
//             </div>

//             <div className="border-t pt-4 text-xs text-muted-foreground text-center">
//               Terms & Conditions: Payment is due within 15 days. Late fees may apply.
//             </div>
//           </DialogContent>
//         </Dialog>
//       </div>
//     </DashboardLayout>
//   )
// }

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import DashboardLayout from "@/components/layout/dashboard-layout"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { CreditCard, Download, Eye } from "lucide-react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { getCurrentUser, getProfileById, getProfiles } from "@/lib/browser-storage"
import { generatePDF } from "@/lib/pdf-generator"

const getInvoicesByPatientId = (patientId: string) => [
  {
    id: "1",
    invoiceNumber: "INV-001",
    createdAt: "2024-05-01",
    dueDate: "2024-05-10",
    status: "paid",
    doctorId: "doc123",
    amount: 2000,
    taxRate: 18,
    taxAmount: 360,
    totalAmount: 2360,
    items: [
      { id: "i1", description: "Consultation", amount: 1000 },
      { id: "i2", description: "X-Ray", amount: 1000 },
    ],
  },
  {
    id: "2",
    invoiceNumber: "INV-002",
    createdAt: "2024-04-15",
    dueDate: "2024-04-22",
    status: "unpaid",
    doctorId: "doc456",
    amount: 1500,
    taxRate: 12,
    taxAmount: 180,
    totalAmount: 1680,
    items: [
      { id: "i1", description: "Blood Test", amount: 500 },
      { id: "i2", description: "Ultrasound", amount: 1000 },
    ],
  },
  {
    id: "3",
    invoiceNumber: "INV-003",
    createdAt: "2024-03-10",
    dueDate: "2024-03-17",
    status: "overdue",
    doctorId: "doc789",
    amount: 800,
    taxRate: 5,
    taxAmount: 40,
    totalAmount: 840,
    items: [{ id: "i1", description: "General Checkup", amount: 800 }],
  },
  {
    id: "4",
    invoiceNumber: "INV-004",
    createdAt: "2024-02-20",
    dueDate: "2024-02-27",
    status: "paid",
    doctorId: "doc123",
    amount: 2200,
    taxRate: 18,
    taxAmount: 396,
    totalAmount: 2596,
    items: [
      { id: "i1", description: "MRI Scan", amount: 2000 },
      { id: "i2", description: "Report Charges", amount: 200 },
    ],
  },
  {
    id: "5",
    invoiceNumber: "INV-005",
    createdAt: "2024-01-05",
    dueDate: "2024-01-12",
    status: "paid",
    doctorId: "doc456",
    amount: 1000,
    taxRate: 10,
    taxAmount: 100,
    totalAmount: 1100,
    items: [
      { id: "i1", description: "ECG", amount: 500 },
      { id: "i2", description: "Consultation", amount: 500 },
    ],
  },
]

export default function InvoicesPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [profileData, setProfileData] = useState<any>(null)
  const [invoices, setInvoices] = useState<any[]>([])
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null)
  const [isViewOpen, setIsViewOpen] = useState(false)

  useEffect(() => {
    const user = getCurrentUser()
    if (!user) return router.push("/")
    const profile = getProfileById(user.id)
    if (!profile) return router.push("/")
    if (profile.role !== "patient") return router.push("/dashboard")

    setProfileData(profile)
    const raw = getInvoicesByPatientId(user.id)
    const enriched = raw.map(inv => {
      const doc = getProfiles().find(p => p.id === inv.doctorId)
      return { ...inv, doctorName: doc?.fullName || "Unknown Doctor" }
    })
    setInvoices(enriched)
    setLoading(false)
  }, [router])

  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString(undefined, {
      year: "numeric",
      month: "long",
      day: "numeric",
    })

  const formatCurrency = (amt: number) =>
    new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
    }).format(amt)

  const statusClasses: Record<string, string> = {
    paid: "bg-green-100 text-green-800 hover:scale-105",
    unpaid: "bg-yellow-100 text-yellow-800 hover:scale-105",
    overdue: "bg-red-100 text-red-800 hover:scale-105",
  }

  const handleView = (inv: any) => {
    setSelectedInvoice(inv)
    setIsViewOpen(true)
  }

  const handleDownload = (inv: any) => {
    const items = inv.items.map((i: any) => `${i.description}: ${formatCurrency(i.amount)}`).join("\n")
    const content = `# Invoice ${inv.invoiceNumber}

**Date:** ${formatDate(inv.createdAt)}  
**Due:** ${formatDate(inv.dueDate)}  
**Status:** ${inv.status.toUpperCase()}  
**Doctor:** ${inv.doctorName}

### Items
${items}

**Subtotal:** ${formatCurrency(inv.amount)}  
**Tax (${inv.taxRate}%):** ${formatCurrency(inv.taxAmount)}  
**Total:** ${formatCurrency(inv.totalAmount)}`
    generatePDF(content, `invoice-${inv.invoiceNumber}.pdf`)
  }

  if (loading || !profileData) {
    return <div className="flex items-center justify-center h-screen">Loading…</div>
  }

  return (
    <DashboardLayout
      userRole={profileData.role}
      userName={profileData.fullName}
      userAvatar={profileData.avatarUrl}
    >
      <div className="p-6">
        <h1 className="text-3xl font-bold text-black mb-6">My Invoices</h1>

        <Card className="rounded-xl animate-fadeIn">
          <CardHeader>
            <CardTitle className="flex items-center text-sky-600">
              <CreditCard className="mr-2 h-5 w-5 text-sky-500" /> Billing History
            </CardTitle>
            <CardDescription>View and manage your invoices</CardDescription>
          </CardHeader>
          <CardContent>
            {invoices.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-sky-50">
                    <TableRow>
                      {["Invoice #", "Doctor", "Date", "Amount", "Status", "Actions"].map((h, idx) => (
                        <TableHead
                          key={h}
                          className={idx === 5 ? "text-right whitespace-nowrap" : "whitespace-nowrap"}
                        >
                          {h}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {invoices.map(inv => (
                      <TableRow
                        key={inv.id}
                        className="transition-all duration-200 hover:scale-[1.01] hover:shadow-md hover:bg-sky-50"
                      >
                        <TableCell>{inv.invoiceNumber}</TableCell>
                        <TableCell>{inv.doctorName}</TableCell>
                        <TableCell>{formatDate(inv.createdAt)}</TableCell>
                        <TableCell>{formatCurrency(inv.totalAmount)}</TableCell>
                        <TableCell>
                          <Badge className={`transition-transform duration-200 ${statusClasses[inv.status]}`}>
                            {inv.status.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="inline-flex gap-2">
                            <Button
                              className="bg-sky-500 hover:bg-sky-600 text-white text-sm transition-all duration-200 hover:scale-105"
                              onClick={() => handleView(inv)}
                            >
                              <Eye className="mr-1 h-4 w-4" /> View
                            </Button>
                            <Button
                              className="bg-green-600 hover:bg-green-700 text-white text-sm transition-all duration-200 hover:scale-105"
                              onClick={() => handleDownload(inv)}
                            >
                              <Download className="mr-1 h-4 w-4" /> Download
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center p-12 text-center text-gray-500">
                <CreditCard className="mb-4 h-8 w-8 text-sky-300" />
                <h3 className="text-lg font-medium">No Invoices Found</h3>
                <p>You don’t have any invoices yet.</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
          <DialogContent className="max-w-2xl bg-white rounded-xl shadow-lg border p-6">
            <div className="text-center mb-4">
              <img
                src="https://i.pinimg.com/originals/3f/d7/d6/3fd7d62d51f0ce46112f4d7eb562fa93.png"
                alt="Health Care Logo"
                className="h-12 mx-auto mb-2"
              />
              <h2 className="text-2xl font-bold text-sky-700">Health Care</h2>
              <p className="text-sm text-gray-500">Invoice Summary</p>
              <hr className="my-4 border-sky-200" />
            </div>

            <div className="grid grid-cols-2 text-sm mb-6 gap-4">
              <div>
                <p className="text-muted-foreground font-medium">Invoice No:</p>
                <p>{selectedInvoice?.invoiceNumber}</p>
                <p className="text-muted-foreground font-medium mt-2">Doctor:</p>
                <p>{selectedInvoice?.doctorName}</p>
              </div>
              <div className="text-right">
                <p className="text-muted-foreground font-medium">Date:</p>
                <p>{formatDate(selectedInvoice?.createdAt)}</p>
                <p className="text-muted-foreground font-medium mt-2">Due Date:</p>
                <p>{formatDate(selectedInvoice?.dueDate)}</p>
              </div>
            </div>

            <div className="overflow-x-auto mb-6">
              <table className="w-full border border-sky-200 text-sm">
                <thead className="bg-sky-100 text-sky-700">
                  <tr>
                    <th className="p-2 border border-sky-200 text-left">Item</th>
                    <th className="p-2 border border-sky-200 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedInvoice?.items?.map((item: any) => (
                    <tr key={item.id} className="hover:bg-green-50">
                      <td className="p-2 border border-sky-200">{item.description}</td>
                      <td className="p-2 border border-sky-200 text-right">
                        {formatCurrency(item.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot className="bg-green-100 text-green-700">
                  <tr>
                    <td className="p-2 border border-sky-200 font-semibold">Subtotal</td>
                    <td className="p-2 border border-sky-200 text-right">{formatCurrency(selectedInvoice?.amount)}</td>
                  </tr>
                  <tr>
                    <td className="p-2 border border-sky-200 font-semibold">Tax ({selectedInvoice?.taxRate}%)</td>
                    <td className="p-2 border border-sky-200 text-right">{formatCurrency(selectedInvoice?.taxAmount)}</td>
                  </tr>
                  <tr>
                    <td className="p-2 border border-sky-200 font-bold">Total</td>
                    <td className="p-2 border border-sky-200 text-right font-bold">{formatCurrency(selectedInvoice?.totalAmount)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <div className="border-t pt-4 text-xs text-muted-foreground text-center">
              Terms & Conditions: Payment is due within 15 days. Late fees may apply.
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}

"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import DashboardLayout from "@/components/layout/dashboard-layout"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Pill, Download, Plus } from "lucide-react"
import {
  getCurrentUser,
  getProfileById,
  getPrescriptionsByPatientId,
  getPrescriptionsByDoctorId,
  getProfiles,
} from "@/lib/browser-storage"
import { generatePDF } from "@/lib/pdf-generator"
import PrescriptionForm from "@/components/prescriptions/prescription-form"

export default function PrescriptionsPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [profileData, setProfileData] = useState<any>(null)
  const [prescriptions, setPrescriptions] = useState<any[]>([])
  const [isFormOpen, setIsFormOpen] = useState(false)

  useEffect(() => {
    const user = getCurrentUser()
    if (!user) return router.push("/")

    const profile = getProfileById(user.id)
    if (!profile) return router.push("/")

    setProfileData(profile)
    const all = getProfiles()
    if (profile.role === "patient") {
      setPrescriptions(
        getPrescriptionsByPatientId(user.id).map((p) => ({
          ...p,
          doctorName:
            all.find((x) => x.id === p.doctorId)?.fullName ||
            "Unknown Doctor",
        }))
      )
    } else {
      setPrescriptions(
        getPrescriptionsByDoctorId(user.id).map((p) => ({
          ...p,
          patientName:
            all.find((x) => x.id === p.patientId)?.fullName ||
            "Unknown Patient",
        }))
      )
    }
    setLoading(false)
  }, [router, isFormOpen])

  const fmtDate = (iso: string) =>
    new Date(iso).toLocaleDateString(undefined, {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  const fmtTime = (iso: string) =>
    new Date(iso).toLocaleTimeString(undefined, {
      hour: "2-digit",
      minute: "2-digit",
    })

  const handleDownloadPDF = (rx: any) => {
    const patientOrDoctor =
      profileData.role === "doctor" ? rx.patientName : rx.doctorName
    const barcodePDF417 = encodeURIComponent(rx.id)
    const sigAvatar = `https://api.adorable.io/avatars/100/${Math.random()
      .toString(36)
      .slice(2)}.png`

    // Base64‐inline your logo, truncated here for brevity:
    const logoDataUri =
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATEAAAEACAIAAABUIdY3..."

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>RX-${rx.id}</title>
  <style>
    body { font-family: sans-serif; position: relative; margin: 40px; }
    /* watermark */
    body::before {
      content: "HealthCare";
      position:absolute; top:50%; left:50%;
      transform:translate(-50%,-50%) rotate(-30deg);
      font-size:80px; color:rgba(56,189,248,0.1);
      white-space:nowrap;
    }
    .header { display:flex; justify-content:space-between; font-size:12px; color:#0f766e; }
    .left img { width:60px; float:left; margin-right:8px; }
    .divider { border-bottom:1px solid #bae6fd; margin:8px 0; }
    h2 { margin:12px 0 4px; color:#0f766e; font-size:14px; }
    table { width:100%; border-collapse:collapse; margin:8px 0; font-size:12px; }
    th, td { border:1px solid #bae6fd; padding:6px 8px; text-align:left; }
    th { background:#e0f2fe; }
    .footer { display:flex; justify-content:space-between; align-items:center; margin-top:24px; }
    .barcode2d img { width:120px; }
    .sig-img { width:120px; }
  </style>
</head>
<body>
  <div class="header">
    <div class="left">
      <img src="https://i.pinimg.com/originals/3f/d7/d6/3fd7d62d51f0ce46112f4d7eb562fa93.png" alt="Logo"/>
      <strong style="color:#149ca1">Dr. Manoj Smith</strong><br/>
      M.B.B.S. | Reg. No. 123456<br/>
      Mob: 9876543210
    </div>
    <div style="text-align:right;">
      <strong style="color:#0c4a6e">Health Care Clinic</strong><br/>
      Elm St, Metropolis – 123456<br/>
      Ph: 0123-456789 | 10:00–16:00<br/>
      Closed: Thursday
    </div>
  </div>

  <div class="divider"></div>

  <h2>Patient Details</h2>
  <table>
    <tr><th>ID</th><td>${rx.id}</td></tr>
    <tr><th>Name / Gender / Age</th><td>${patientOrDoctor} / ${rx.gender} / ${rx.age}</td></tr>
    <tr><th>Address</th><td>${rx.address||"–"}</td></tr>
    <tr><th>Weight / Height</th><td>${rx.weight||"–"}kg / ${rx.height||"–"}cm</td></tr>
    <tr><th>BMI / BP</th><td>${rx.bmi||"–"} / ${rx.bp||"–"}</td></tr>
    <tr><th>Referred By</th><td>Dr. Manoj Smith</td></tr>
    <tr><th>Date / Time</th><td>${fmtDate(rx.date)} / ${fmtTime(rx.date)}</td></tr>
  </table>

  <h2>Diagnosis</h2>
  <ul><li>${rx.diagnosis}</li></ul>

  <h2>Medications</h2>
  <table>
    <tr><th>#</th><th>Medicine</th><th>Dosage</th><th>Frequency</th><th>Duration</th></tr>
    ${rx.medications
      .map(
        (m: any, i: number) => `
    <tr>
      <td>${i + 1}</td>
      <td>${m.name}</td>
      <td>${m.dosage}</td>
      <td>${m.frequency}</td>
      <td>${m.duration}</td>
    </tr>`
      )
      .join("")}
  </table>

  <h2>Advice Given</h2>
  <p>${rx.instructions}</p>
  <p><em>Date: ${fmtDate(rx.date)}</em></p>

  <div class="divider"></div>

  <div class="footer">
    <div class="barcode2d">
      <img src="https://api-bwipjs.metafloor.com/?bcid=pdf417&text=${barcodePDF417}" alt="PDF417"/>
    </div>
    <div style="text-align:right;">
      <img class="sig-img" src="https://th.bing.com/th/id/OIP.G5e_dh8tD8yGLSXUxauCqAHaCx?cb=iwp2&rs=1&pid=ImgDetMain" alt="Signature"/><br/>
      <span style="color:#149ca1">Dr. Manoj Smith</span>
    </div>
  </div>
</body>
</html>
    `
    generatePDF(html, `prescription-${rx.id}.pdf`)
  }

  if (loading || !profileData) {
    return <div className="flex items-center justify-center h-screen">Loading…</div>
  }

  return (
    <DashboardLayout
      userRole={profileData.role}
      userName={profileData.fullName}
      userAvatar={profileData.avatarUrl}
    >
      <div className="p-6">
        <div className="flex justify-between items-center mb-8 flex-wrap gap-4">
          {/* Title in solid black */}
          <h1 className="text-3xl font-bold text-black">
            {profileData.role === "doctor" ? "Manage Prescriptions" : "My Prescriptions"}
          </h1>

          {profileData.role === "doctor" && (
            <Button
              onClick={() => setIsFormOpen(true)}
              className="bg-green-600 hover:bg-green-700 text-white rounded-xl whitespace-nowrap"
            >
              <Plus className="mr-2 h-4 w-4" /> New Prescription
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {prescriptions.length > 0 ? (
            prescriptions.map((rx) => (
              <Card key={rx.id} className="overflow-hidden rounded-xl">
                <CardHeader className="bg-sky-50">
                  <div className="flex justify-between items-start flex-wrap">
                    <div className="min-w-0">
                      <CardTitle className="flex items-center text-lg text-sky-600">
                        <Pill className="h-5 w-5 mr-2 text-sky-500" /> Prescription
                      </CardTitle>
                      <CardDescription className="truncate">
                        {fmtDate(rx.date)} {fmtTime(rx.date)}
                      </CardDescription>
                    </div>
                    <Badge className="flex items-center bg-white text-green-600 border-green-300 whitespace-nowrap mt-2 md:mt-0">
                      <span className="inline-block h-2 w-2 bg-green-600 rounded-full mr-1" />
                      Active
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="pt-6 space-y-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      {profileData.role === "doctor" ? "Patient" : "Doctor"}
                    </p>
                    <p className="truncate">
                      {profileData.role === "doctor" ? rx.patientName : rx.doctorName}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Medications</p>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                      {rx.medications.map((m: any) => (
                        <li key={m.id} className="truncate">
                          <span className="font-medium">{m.name}</span> — {m.dosage}, {m.frequency}, {m.duration}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Instructions</p>
                    <p className="truncate">{rx.instructions}</p>
                  </div>
                </CardContent>

                <CardFooter className="bg-sky-100 border-t border-sky-200">
                  {/* Download button now solid green */}
                  <Button
                    className="w-full rounded-xl bg-green-600 hover:bg-green-700 text-white"
                    onClick={() => handleDownloadPDF(rx)}
                  >
                    <Download className="mr-2 h-4 w-4" /> Download PDF
                  </Button>
                </CardFooter>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center p-12 text-gray-500">
              No prescriptions found.
            </div>
          )}
        </div>

        {profileData.role === "doctor" && (
          <PrescriptionForm
            doctorId={profileData.id}
            open={isFormOpen}
            onOpenChange={setIsFormOpen}
          />
        )}
      </div>
    </DashboardLayout>
  )
}

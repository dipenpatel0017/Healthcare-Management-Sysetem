"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import DashboardLayout from "@/components/layout/dashboard-layout"
import BookAppointmentForm from "./book-appointment-form"
import { getCurrentUser, getProfileById } from "@/lib/browser-storage"

export default function BookAppointmentPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [profileData, setProfileData] = useState<any>(null)

  // 🔹 Dummy doctor list (replace this with real data later if needed)
  const dummyDoctors = [
    { id: "doc-001", full_name: "Dr. Aditi Sharma", specialization: "Cardiologist" },
    { id: "doc-002", full_name: "Dr. Ravi Kumar", specialization: "Dermatologist" },
    { id: "doc-003", full_name: "Dr. Nisha Verma", specialization: "Pediatrician" },
    { id: "doc-004", full_name: "Dr. Arjun Singh", specialization: "Orthopedic" },
    { id: "doc-005", full_name: "Dr. Meera Joshi", specialization: "General Physician" },
  ]

  useEffect(() => {
    const fetchData = async () => {
      const user = getCurrentUser()

      if (!user) {
        router.push("/")
        return
      }

      const profile = getProfileById(user.id)

      if (!profile) {
        router.push("/")
        return
      }

      if (profile.role !== "patient") {
        router.push("/dashboard")
        return
      }

      setProfileData(profile)
      setLoading(false)
    }

    fetchData()
  }, [router])

  if (loading || !profileData) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>
  }

  return (
    <DashboardLayout userRole={profileData.role} userName={profileData.fullName} userAvatar={profileData.avatarUrl}>
      <div className="p-6">
        <h1 className="text-3xl font-bold mb-8">Book an Appointment</h1>
        <div className="max-w-2xl mx-auto">
          <BookAppointmentForm
            patientId={profileData.id}
            patientName={profileData.fullName}
            doctors={dummyDoctors}
          />
        </div>
      </div>
    </DashboardLayout>
  )
}

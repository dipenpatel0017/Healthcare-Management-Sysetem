"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { CalendarIcon } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"
import { createClient } from "@/lib/supabase/client"
import { v4 as uuidv4 } from "uuid"

function isValidUUID(id: string) {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
  return uuidRegex.test(id)
}

function formatDateForDisplay(date: Date): string {
  const options: Intl.DateTimeFormatOptions = {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
  }
  return date.toLocaleDateString("en-US", options)
}

function formatDateForStorage(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`
}

interface Doctor {
  id: string
  full_name: string
  specialization: string | null
}

interface BookAppointmentFormProps {
  patientId: string
  patientName: string
  doctors: Doctor[]
}

export default function BookAppointmentForm({ patientId, patientName, doctors }: BookAppointmentFormProps) {
  const router = useRouter()
  const supabase = createClient()
  const [isLoading, setIsLoading] = useState(false)
  const [selectedDoctors, setSelectedDoctors] = useState<string[]>([])
  const [date, setDate] = useState<Date>()
  const [time, setTime] = useState("")
  const [reason, setReason] = useState("")

  const timeSlots = [
    "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
    "13:00", "13:30", "14:00", "14:30", "15:00", "15:30",
    "16:00", "16:30", "17:00",
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (selectedDoctors.length === 0 || !date || !time || !reason) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const formattedDate = formatDateForStorage(date)
      const validPatientId = isValidUUID(patientId) ? patientId : uuidv4()

      const appointmentsToInsert = selectedDoctors.map((doctorId) => ({
        id: uuidv4(),
        doctor_id: isValidUUID(doctorId) ? doctorId : uuidv4(),
        patient_id: validPatientId,
        title: "Consultation",
        appointment_date: formattedDate,
        appointment_time: time,
        status: "upcoming",
        reason,
        notes: "",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }))

      const { error } = await supabase.from("appointments").insert(appointmentsToInsert)
      if (error) throw error

      toast({
        title: "Appointment booked",
        description: "Your appointment has been booked successfully.",
      })

      router.push("/appointment-calendar")
    } catch (error: any) {
      toast({
        title: "Error booking appointment",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="rounded-xl">
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="patientName">Patient Name</Label>
            <Input className="rounded-xl" id="patientName" value={patientName} disabled />
          </div>

          <div className="space-y-2">
            <Label htmlFor="appointmentDate">Appointment Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? formatDateForDisplay(date) : "Select date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>Select Doctors</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left rounded-xl">
                  {selectedDoctors.length > 0
                    ? doctors
                        .filter((doc) => selectedDoctors.includes(doc.id))
                        .map((doc) => doc.full_name)
                        .join(", ")
                    : "Select doctors"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[300px] max-h-64 overflow-y-auto rounded-md shadow-md p-3 bg-white border">
                <div className="space-y-2">
                  {doctors.map((doctor) => (
                    <div key={doctor.id} className="flex items-center gap-2">
                      <Checkbox
                        id={doctor.id}
                        checked={selectedDoctors.includes(doctor.id)}
                        onCheckedChange={(checked) => {
                          setSelectedDoctors((prev) =>
                            checked ? [...prev, doctor.id] : prev.filter((id) => id !== doctor.id)
                          )
                        }}
                      />
                      <label
                        htmlFor={doctor.id}
                        className="text-sm text-gray-700 leading-tight cursor-pointer"
                      >
                        {doctor.full_name} ({doctor.specialization || "General"})
                      </label>
                    </div>
                  ))}
                </div>
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="time">Appointment Time</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left rounded-xl">
                  {time || "Select time"}
                </Button>
              </PopoverTrigger>
              <PopoverContent>
                <div className="grid grid-cols-3 gap-2">
                  {timeSlots.map((slot) => (
                    <Button
                      key={slot}
                      type="button"
                      variant={time === slot ? "default" : "outline"}
                      className="text-sm"
                      onClick={() => setTime(slot)}
                    >
                      {slot}
                    </Button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="reason">Reason for Appointment</Label>
            <Textarea
              className="rounded-xl"
              id="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Please describe your symptoms or reason for the appointment"
              rows={4}
            />
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? "Booking Appointment..." : "Book Appointment"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
